# Quality Companion 1.2.0 — Enhanced CO Quality Engine

## Purpose

Quality Companion accepts a CO Excel export and verifies each complaint row against the supplied CO quality rules.

The build follows the execution pattern used by the IMDRF Coding Companion:

**Input → normalized fields → rule library → rule handler → evidence → PASS / FAIL / REVIEW / N/A**

The IMDRF coding engine remains a separate semantic layer:

**Event / Product Analysis → historical-example predictor → IMDRF code candidates → confidence → comparison with actual coding**

No external API is required for Excel QA.

## Rule execution architecture

1. `rules/all-rules.json`
   - Contains the workbook/process rule inventory.
   - The 44 `type: "CO"` records are the executable CO verification rules.
   - Workflow rules remain retained for traceability and future page-capture execution.

2. `rules/execution-map.json`
   - Explicit registry for the 44 CO checks.
   - Records fields, execution mode, semantic status and source.

3. `src/quality-engine.js`
   - Resolves structured Excel fields first.
   - Uses punctuation-insensitive field matching for export variants.
   - Executes deterministic handlers for the supplied CO rules.
   - Executes semantic IMDRF checks for AI/AR coding.
   - Returns an auditable result containing:
     - rule ID
     - rule name
     - status
     - current value
     - expected value
     - rule logic
     - referenced fields
     - execution mode
     - recommendation
     - source

4. `src/predictor.js` + `src/training-data.js`
   - Same historical-example similarity design used by the IMDRF Coding Companion.
   - Used only where the CO rule requires semantic coding validation.
   - Does not overwrite the user's coding.

## Supplied CO rules implemented

All 44 CO checks are represented and executable:

- CO-001 Product Summary Consistency
- CO-002 Product Link Matches Model Number
- CO-003 Assigned Owner Consistency
- CO-004 Customer Letter Consistency
- CO-005 Report Source Valid Value
- CO-006 Communication Channel Valid Value
- CO-007 Language Not Blank
- CO-008 Event Date / Unknown Checkbox Consistency
- CO-009 Country of Occurrence Not Blank
- CO-010 Reporter Phone Not Blank
- CO-011 Reporter Email Not Blank
- CO-012 Reporter Occupation Not Blank
- CO-013 Customer Name Not Blank
- CO-014 Customer Address Not Blank
- CO-015 Due Diligence Contact Occupation Not Blank
- CO-016 Manufacture Date Required for Reportable Events
- CO-017 Product Lot/Serial Number Not Blank
- CO-018 Lot Unknown Checkbox Consistency
- CO-019 Quantity Affected Valid
- CO-020 Verify Recycled Single Use Device
- CO-021 Culture Test Positive Valid Value
- CO-022 Verify Investigation Classification
- CO-023 Verify Customer Letter Sent Date
- CO-024 Verify Report Source Other
- CO-025 Verify Device Operator
- CO-026 Verify Procedure Name
- CO-027 Verify Procedure Outcome
- CO-028 Verify Procedure Type
- CO-029 Verify Patient Outcome
- CO-030 Verify When Procedure Did Event Occur
- CO-031 Verify Event Occurred At
- CO-032 Verify Item Code
- CO-033 Verify Product Family
- CO-034 Verify Manufacture Date
- CO-035 Verify Asset Flag
- CO-036 Verify Other Devices Involved
- CO-037 Verify Device Available for Evaluation
- CO-038 Verify Product Return Status
- CO-039 Verify Death
- CO-040 Verify Procedure Prolonged
- CO-041 Verify Patient Infection
- CO-042 Verify AI Codes
- CO-043 Verify AR Codes
- CO-044 Verify Health Effect Codes

## Important rule behavior

### NI normalization

The engine treats:

- `NI`
- `No Information`
- `No Information Available`

as the same normalized value for conditional comparisons, while preserving the original value shown to the user.

This prevents a rule from failing merely because one export says `NI` and another says `No Information`.

`Asked but unknown` remains a separate value because the supplied rules explicitly distinguish it.

### Product Lot / Serial Number

The engine accepts punctuation/spacing variants such as:

- `Product Lot/Serial Number`
- `Product Lot / Serial Number`
- `Complaint: Product Lot / Serial Number`

The value is read from the structured Excel map before narrative parsing.

### Customer Letter

CO-004 and CO-023 are kept as separate checks because the supplied rule set contains both:
- overall Required/Attached/Sent consistency
- specific Sent Date verification

The extension does not silently delete either rule.

### Health-effect coding

CO-044 executes the explicit mappings supplied in the verification matrix, including:
- `Procedure` + `No serious injury/No adverse patient effect` or `None` or `No information available` → `E2403/F26`
- `Reprocessing` / `Service or maintenance` / `Installation` / `Lab or demonstration` / `Out-of-box failure` + `None` → `E2403/F27`
- `Asked but unknown` + `No information available` → `E2401/F24`
- `During setup/inspection for use or before patient arrival` → `E2403/F2601`
- `Procedural delay` + `Olympus Backup Device` / `Competitor Device` → add `F2301`

If no supplied mapping branch is triggered, CO-044 passes because no correction is required by the supplied matrix.

### AI / AR coding

CO-042:
- parses A/G/C/D tuples
- compares AI Codes with complete coding tuples available in the export
- supports flattened `Complaint Codes` exports
- performs failure-by-failure semantic comparison using the IMDRF historical dataset
- shows recommendations rather than silently changing codes

CO-043:
- extracts actual AR A-codes
- generates IMDRF candidates from Event Description
- compares the actual code with the top candidate and confidence

## Excel behavior

- Upload `.xlsx`
- First worksheet is read locally
- Every non-empty data row is one complaint
- Each complaint receives the full CO rule set
- Results are grouped by Complaint Number
- Filters: ALL / FAIL / REVIEW / PASS
- Export JSON or CSV
- No spreadsheet data is sent to a server

## Testing performed

The uploaded 15-row CO input was used as a smoke test against the engine.

Result:
- 15 complaint rows
- 47 CO checks per row = 705 CO checks
- plus investigation/documentation/traceability checks generated by the engine
- 870 total engine results
- 548 PASS
- 171 FAIL
- 89 REVIEW
- 62 N/A
- 0 execution errors

The sample input is not bundled into the extension.

## Install

1. Extract the ZIP.
2. Open `chrome://extensions`.
3. Enable Developer mode.
4. Select **Load unpacked**.
5. Select the extracted `Quality Companion` folder.
6. Open the extension side panel.
7. Upload the CO `.xlsx`.

## Result interpretation

- **PASS** — supplied rule evaluated successfully.
- **FAIL** — supplied rule condition was not satisfied.
- **REVIEW** — the supplied rule requires semantic/contextual evidence that the local deterministic engine cannot safely establish.
- **N/A** — the supplied rule's condition does not apply.

The extension is a quality-assurance decision-support tool. It does not replace investigator/reviewer approval.


## Recycled Single Use Device rule
CO-020 is the single authoritative check. CO-039 has been removed as a duplicate. The rule is: Reuse Device Type -> recycled single-use = No; Single Use Device Type + Usage of Device = Reuse -> recycled single-use = Yes; other Single Use combinations are N/A unless another rule applies.

## Transparency
Every check has a “Show rule behind this check” control displaying Rule ID, rule logic, referenced fields, source, and execution mode.


## v1.3.0 rule correction
- Removed duplicate CO-020: Usage of Device Derived From Device Type.
- CO-024 is the single authoritative check for Report Source (Other): IF Complaint: Report Source is Other or Others AND Complaint: Report Source (Other) is not blank THEN PASS, ELSE FAIL.

## v1.3.8 rule correction
- CO-024 is the single authoritative Report Source (Other) validation.
- If Report Source is `Other` or `Others`, Report Source (Other) must be populated; otherwise CO-024 = FAIL.
- If Report Source is any value other than `Other`/`Others`, CO-024 = PASS and no Report Source (Other) population is required.
- CO-006 remains removed.
- CO-029 retains the latest user-specified PASS logic for NI / No Information, N/A Patient Outcome, and Event Occurred At values outside the specified conditional set.


CO-044 correction: E2401/F24 is recognized for Patient Outcome NI and Event Occurred At Asked but unknown or NI/No Information.


## DOC-DHR
DOC-DHR — DHR/SHR Review documentation: DHR/SHR requirement needs manual confirmation. This item is not evaluated as an automated PASS/FAIL check.


## v1.4.0 — IMDRF Coding Companion integration

Quality Companion now uses the IMDRF Coding Companion assets directly for coding verification:

- Full IMDRF Coding Examples: 6,171 coded examples.
- Companion predictor with historical A/G/C/D relationships and holistic tuple evidence.
- Official IMDRF 2026 terminology loader for Annex A, B, C, D and G.
- **CO-043 — AR verification:** Event Description → As Reported A-code. The result shows the actual AR code, historical-dataset candidates, official IMDRF candidates, source agreement, and tool-calculated match confidence.
- **CO-042 — AI verification:** Each Product Analysis failure is evaluated independently against the actual As Investigated A/G/C/D tuples. The result shows the best matching tuple, code-match score, confidence, historical suggestions and official terminology candidates.
- A full AI tuple match is **PASS**; a partial/alternative match is **REVIEW**; an unsupported mismatch is **FAIL**.
- Confidence is calculated by Quality Companion from semantic coding evidence and code agreement. It is not an IMDRF-assigned regulatory confidence.
- Human review remains required before accepting or changing regulatory coding.

### Data flow

`Event Description → historical IMDRF dataset + official IMDRF 2026 → AR A-code suggestion → compare actual AR`

`Product Analysis failure → historical IMDRF dataset + A/G/C/D relationships + official terminology → AI tuple suggestion → compare actual AI tuple → confidence`

The official terminology loader is cached in Chrome storage after a successful first load. If the official network resource is unavailable, the historical dataset verification remains available and the UI explicitly reports the missing official source.

## v1.4.6 changes
- Product Analysis is split into individual failure statements.
- Narrative/report prose is ignored.
- Each failure is coded independently; the whole paragraph is never coded as one failure.
- Added prediction and official terminology caches.
- Removed holistic A/G/C/D Cartesian scoring from CO-042 to reduce execution time.
- Exact CO input regression workbook is included under test-fixtures/.
