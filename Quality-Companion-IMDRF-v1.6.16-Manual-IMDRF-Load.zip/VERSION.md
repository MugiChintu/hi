# Quality Companion v1.6.11

- Keeps `executionMode` and `source` out of exported reports.
- Keeps human-readable Rule Logic.
- Adds a dedicated `ruleLogicCode` report column with structured, code-block-style pseudo-logic for complex rules.
- Uses multiline IF / ELSE IF / ELSE / THEN formatting and monospace styling in the Excel report.
- Preserves IMDRF A/G/C/D suggestions and all prior UI behavior.
