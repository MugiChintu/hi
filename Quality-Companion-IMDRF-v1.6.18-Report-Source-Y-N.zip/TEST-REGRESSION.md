# Excel / IMDRF Regression Test

Exact test workbook included:
`test-fixtures/CO File Input (3).xlsx`

Expected workbook characteristics:
- XLSX
- 1 worksheet
- 6 complaint records (7 rows including header)
- 146 columns
- approximately 35.8 KB

Required execution flow:
1. Load workbook without waiting for IMDRF initialization.
2. Convert all 6 records to complaint objects.
3. Execute all existing Quality Companion CO/CI checks.
4. Execute CO-043 AR-code verification using Event Description.
5. Execute CO-042 AI-code verification using Product Analysis failures.
6. Compare suggested IMDRF coding against actual AR/AI coding.
7. Produce match status and confidence without blocking workbook loading.
