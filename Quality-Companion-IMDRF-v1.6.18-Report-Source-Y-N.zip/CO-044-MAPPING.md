# CO-044 — Verify Health Effect Codes

Fields:
- Has Health Effect Codes
- Complaint Codes - Patient
- Patient Outcome
- Event Occurred At
- Procedure Outcome

Mappings:
- Procedure + no harm/NI -> E2403 / F26
- Reprocessing / Service or maintenance / Installation / Lab or demonstration / Out-of-box failure + None -> E2403 / F27
- Asked but unknown + NI -> E2401 / F24
- During setup/inspection for use or before patient arrival -> E2403 / F2601
- Procedural delay + Olympus Backup Device or Competitor Device -> add F2301

Only these supplied mappings are evaluated. NI, No Information, and No Information Available are normalized to NI. If no mapping is triggered, no correction is proposed.
