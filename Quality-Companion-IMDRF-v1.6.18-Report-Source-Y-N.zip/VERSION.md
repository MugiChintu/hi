# Quality Companion v1.6.18

Report Source verification now treats Complaint: Reporter is Healthcare Professional? as Y/N. Y requires Healthcare Professional in Report Source; N + @olympus requires Company Representative; otherwise User Facility. Existing matching source passes; missing expected source returns REVIEW.
