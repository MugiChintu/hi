# Coding dataset enhancement

- Workbook: `coding dataset(1).xlsx`
- Sheets: Annex A Coding Mapping, Annex G Coding Mapping, HMI
- Total uploaded rows preserved: **2590**
- Unique exact rows: **2218**
- Exact duplicate rows preserved: **372**
- Frequency is retained as evidence rather than used for deletion.
- Evidence weight: `1.0 + 0.15 × (frequency - 1)`, capped at `3.0`.
