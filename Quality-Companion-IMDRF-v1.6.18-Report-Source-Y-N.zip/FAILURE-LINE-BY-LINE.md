# Failure-level verification behavior

- Every Product Analysis failure is displayed and checked separately.
- A PTI/GISC annotation on the next visual line is treated as belonging to the preceding failure.
- Annotations such as `GISC_Image Abnormality_PTI6` and `GISC_Leakage_PTI1` are supported.
- A wrapped PTI annotation is never treated as a new failure or attached to the following failure.
- PTI-linked failures are N/A for non-PTI review checks.
- Non-PTI failures are checked independently in Risk Review, Complaint History Review and CAPA History Review.
- The consolidated `DOC-NONPTI-REVIEW` table shows one row per failure.
