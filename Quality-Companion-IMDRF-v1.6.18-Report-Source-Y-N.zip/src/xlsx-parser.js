
function frequencyWeightedCodingEvidence(record) {
  const n = Math.max(1, Number(record?._frequency || 1));
  return Math.min(3, 1 + (n - 1) * 0.15);
}
/* Fast XLSX reader: avoids DOMParser over the entire workbook/sharedStrings XML. */
function xmlUnescape(s){
  return String(s??"").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&amp;/g,"&");
}
function getAttr(tag,name){
  const re=new RegExp("\\b"+name.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\$&")+"\\s*=\\s*([\\\"'])(.*?)\\1","i");
  const m=tag.match(re); return m?m[2]:"";
}
function colName(n){let s="";while(n){let r=(n-1)%26;s=String.fromCharCode(65+r)+s;n=Math.floor((n-1)/26)}return s}
function colNumber(x){let n=0;for(const c of x)n=n*26+c.charCodeAt(0)-64;return n}
function textFromXml(fragment){
  return [...String(fragment).matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/gi)].map(m=>xmlUnescape(m[1])).join("");
}
async function parseXLSX(file){
  if(!file || !file.size) throw Error("The selected Excel file is empty (0 bytes).");
  const progress=(phase,pct,detail)=>{try{globalThis.excelProgress?.(phase,pct,detail)}catch{}};
  progress("Opening Excel workbook",2,`${(file.size/1024/1024).toFixed(2)} MB`);
  const zip=await JSZip.loadAsync(file,{checkCRC32:false,createFolders:false,onUpdate:(meta)=>{
    const p=Number(meta?.percent)||0;
    progress("Reading Excel workbook",Math.max(2,Math.min(30,2+p*0.28)),"decompressing workbook");
  }});
  progress("Workbook archive opened",32,"reading workbook structure");
  const readText=async p=>{const f=zip.file(p);return f?f.async("text"):null;};
  const wbText=await readText("xl/workbook.xml");
  progress("Reading workbook structure",34,"workbook.xml");
  const relText=await readText("xl/_rels/workbook.xml.rels");
  if(!wbText||!relText) throw Error("Invalid XLSX: workbook.xml or workbook relationships are missing.");

  const relMap={};
  for(const m of relText.matchAll(/<Relationship\b([^>]*)\/?>(?:<\/Relationship>)?/gi)){
    const a=m[1]; const id=getAttr(a,"Id"); const target=getAttr(a,"Target"); if(id&&target)relMap[id]=target;
  }

  const shared=[];
  const ssText=await readText("xl/sharedStrings.xml");
  progress("Reading shared text",38,ssText?"sharedStrings.xml":"no shared strings");
  if(ssText){
    /* Parse each shared-string item without building a DOM tree. */
    let si=0;
    for(const m of ssText.matchAll(/<si\b[\s\S]*?<\/si>/gi)){
      shared.push(textFromXml(m[0]));
      if((++si%500)===0) progress("Reading shared text",38+Math.min(10,si/Math.max(1,shared.length)*10),`${si.toLocaleString()} strings`);
    }
  }
  progress("Reading workbook sheets",50,"locating worksheets");

  const sheets=[];
  for(const m of wbText.matchAll(/<sheet\b([^>]*)\/?>(?:<\/sheet>)?/gi)){
    const a=m[1]; const name=xmlUnescape(getAttr(a,"name")); const rid=getAttr(a,"r:id")||getAttr(a,"id");
    if(name) sheets.push({name,rid});
  }
  const result={};
  for(const sh of sheets){
    let target=relMap[sh.rid]||"worksheets/sheet1.xml";
    target=target.replace(/^\/+/g,"");
    if(target.startsWith("/xl/"))target=target.slice(1);
    if(!target.startsWith("xl/"))target="xl/"+target.replace(/^\.\//,"");
    const xml=await readText(target); if(!xml) continue;
    const rows=[];
    const rowMatches=[...xml.matchAll(/<row\b[^>]*>([\s\S]*?)<\/row>/gi)];
    const totalRows=Math.max(1,rowMatches.length);
    for(let ri=0;ri<rowMatches.length;ri++){
      const rm=rowMatches[ri];
      const obj={}; const body=rm[1];
      for(const cm of body.matchAll(/<c\b([^>]*)>([\s\S]*?)<\/c>|<c\b([^>]*)\/>/gi)){
        const a=cm[1]||cm[3]||""; const cell=cm[2]||""; const ref=getAttr(a,"r");
        const rc=ref.match(/^([A-Z]+)\d+$/i); if(!rc) continue; const col=rc[1].toUpperCase(); const type=getAttr(a,"t");
        let v="";
        if(type==="inlineStr"){const is=cell.match(/<is\b[\s\S]*?<\/is>/i); v=is?textFromXml(is[0]):"";}
        else {const vm=cell.match(/<v\b[^>]*>([\s\S]*?)<\/v>/i); v=vm?xmlUnescape(vm[1]):""; if(type==="s")v=shared[Number(v)]??""; else if(type==="b")v=v==="1"?"TRUE":"FALSE";}
        obj[col]=v;
      }
      if(Object.keys(obj).length) rows.push(obj);
      if((ri%100)===0 || ri===rowMatches.length-1){
        const sheetBase=50+(Object.keys(result).length/Math.max(1,sheets.length))*5;
        progress(`Reading ${sh.name}`,sheetBase+Math.round((ri+1)/totalRows*15),`${(ri+1).toLocaleString()}/${totalRows.toLocaleString()} rows`);
        if((ri%500)===0) await new Promise(requestAnimationFrame);
      }
    }
    result[sh.name]=rows;
    progress(`Finished ${sh.name}`,Math.min(70,50+((Object.keys(result).length)/Math.max(1,sheets.length))*20),`${rows.length.toLocaleString()} rows`);
  }
  progress("Excel workbook parsed",70,`${Object.keys(result).length} sheet${Object.keys(result).length===1?"":"s"}`);
  return result;
}
function xlsxRowsToObjects(rows){
  if(!rows.length)return [];
  let max=0; for(const r of rows)for(const k of Object.keys(r))max=Math.max(max,colNumber(k));
  const headers=[];for(let i=1;i<=max;i++)headers.push(rows[0][colName(i)]||"");
  return rows.slice(1).filter(r=>Object.keys(r).length).map(r=>{const o={};headers.forEach((h,i)=>{if(h)o[h]=r[colName(i+1)]??""});return o;});
}
