
function frequencyWeightedCodingEvidence(record) {
  const n = Math.max(1, Number(record?._frequency || 1));
  return Math.min(3, 1 + (n - 1) * 0.15);
}

function normalizeCO044Value(value) {
  return String(value ?? "")
    .trim()
    .toLowerCase()
    .replace(/[–—]/g, "-")
    .replace(/\s+/g, " ");
}
function isCO044None(value) {
  const v = normalizeCO044Value(value);
  return v === "none" || v === "na" || v === "n/a" ||
         v === "no information" || v === "no information available" ||
         v === "ni";
}
class QualityEngine {
  constructor(rules, options={}){
    this.rules=rules||[];
    this.caseData=null;
    this.imdrfStore=options.imdrfStore||globalThis.IMDRF_STORE||null;
    this.predictor=null;
    this.predictionCache=new Map();
    this.officialCache=new Map();
  }

  norm(v){return String(v??"").replace(/\u00a0/g," ").replace(/\s+/g," ").trim();}
  normNarrative(v){return this.norm(v).toLowerCase().replace(/\b\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}\b/g,"").replace(/[^a-z0-9]+/g," ").replace(/\s+/g," ").trim();}
  key(v){
    let x=this.norm(v).toLowerCase().replace(/[^a-z0-9]+/g,"");
    if(x==="noinformation"||x==="noinformationavailable"||x==="noinfo")x="ni";
    if(x==="askedbutunknown"||x==="askedunknown")x="askedbutunknown";
    return x;
  }
  empty(v){return !this.norm(v)||/^(na|n\/a|null|undefined|none|not applicable)$/i.test(this.norm(v));}
  text(page){return this.norm(this.caseData?.pages?.[page]?.text||"");}
  allText(){return Object.values(this.caseData?.pages||{}).map(p=>p.text||"").join("\n");}
  esc(s){return String(s).replace(/[.*+?^${}()|[\]\\]/g,"\\$&");}

  field(text,names){
    const arr=[...new Set((names||[]).filter(Boolean).map(x=>this.norm(x)).filter(Boolean))];
    const page=this.caseData?.currentPageForField||"complaint";
    const fmap=this.caseData?.fieldMaps?.[page]||{};
    for(const name of arr){
      // If the structured Excel map contains the exact field, trust it even when
      // the value is blank. Do NOT fall back to narrative text, because that can
      // accidentally consume the next field's value.
      const direct=fmap[name];
      if(direct!==undefined) return {found:true,value:this.norm(direct),label:name};
    }
    const keyName=n=>this.key(String(n).replace(/^Complaint:\s*/i,""));
    for(const name of arr){
      const nk=keyName(name);
      for(const [k,v] of Object.entries(fmap)){
        if(keyName(k)===nk)return {found:true,value:this.norm(v),label:k};
      }
    }
    if(!text)return {found:false,value:""};
    for(const name of arr){
      const re=new RegExp("(?:^|\\n)\\s*"+this.esc(name)+"\\s*(?:[:\\-]|\\s{2,})\\s*([^\\n\\r]{1,1000})","i");
      const m=text.match(re);
      if(m&&this.norm(m[1]))return {found:true,value:this.norm(m[1]),label:name};
    }
    // Also support label immediately followed by value on same line.
    for(const name of arr){
      const re=new RegExp(this.esc(name)+"\\s*[:\\-]\\s*([^\\n\\r]{1,1000})","i");
      const m=text.match(re);
      if(m&&this.norm(m[1]))return {found:true,value:this.norm(m[1]),label:name};
    }
    return {found:false,value:""};
  }

  names(raw){
    return String(raw||"").split(/[,;•\n]+/)
      .map(x=>this.norm(x).replace(/^Complaint:\s*/i,""))
      .filter(x=>x&&x.length<180);
  }

  pageFor(r){
    const p=this.norm(r.phase||"").toLowerCase();
    if(p.includes("investigation"))return "investigation";
    if(p.includes("complaint"))return "complaint";
    if(p==="co")return "complaint";
    return null;
  }

  result(r,status,message,recommendation="",extra={}){
    return {
      id:r.id,title:r.name||r.field||"Quality check",phase:r.phase,type:r.type,status,message,recommendation,
      ruleLogic:r.logic||"",source:r.source||"CO-CI Rules and process.xlsx",
      fieldsReferenced:this.names(r.fieldsReferenced),
      executionMode:r.type==="CO"?"CO deterministic/semantic handler":"workflow rule handler",
      engineVersion:"1.2",...extra
    };
  }

  comparePages(r,fieldNames,sourcePage,targetPage,label){
    const a=this.field(this.text(sourcePage),fieldNames);
    const b=this.field(this.text(targetPage),fieldNames);
    if(!a.found||!b.found)
      return this.result(r,"REVIEW",`${label||fieldNames[0]} could not be verified on both pages.`,`Verify ${label||fieldNames[0]} on ${sourcePage} and ${targetPage}.`,{current:b.value,expected:a.value});
    if(this.key(a.value)===this.key(b.value))
      return this.result(r,"PASS",`${label||fieldNames[0]} matches between ${sourcePage} and ${targetPage}.`,"",{current:b.value,expected:a.value});
    return this.result(r,"FAIL",`${label||fieldNames[0]} does not match between ${sourcePage} and ${targetPage}.`,`Correct the ${targetPage} value to match ${a.value}.`,{current:b.value,expected:a.value});
  }

  allowed(r,names,allowed){
    const p=this.pageFor(r)||"complaint", f=this.field(this.text(p),names);
    if(!f.found)return this.result(r,"REVIEW",`Could not locate ${names[0]}.`,`Verify ${names[0]} and use one of: ${allowed.join(", ")}.`);
    const ok=allowed.some(x=>this.key(f.value)===this.key(x)||this.key(f.value).includes(this.key(x)));
    return ok?this.result(r,"PASS",`${f.label} has an allowed value.`,"",{current:f.value})
      :this.result(r,"FAIL",`${f.label} has an invalid value.`,`Use one of: ${allowed.join(", ")}.`,{current:f.value,expected:allowed.join(", ")});
  }

  parseCodingTuples(value){
    const s=this.norm(value);
    if(!s)return [];
    const tokens=[...s.matchAll(/\b([AGCD])\s*[-:]?\s*(\d{1,8})\b/gi)]
      .map(m=>({L:m[1].toUpperCase(),code:this.key(m[1]+m[2]),index:m.index}));
    if(!tokens.length)return [];
    const records=[];
    for(const raw of s.split(/\s*;\s*/)){
      const ts=[...raw.matchAll(/\b([AGCD])\s*[-:]?\s*(\d{1,8})\b/gi)]
        .map(m=>({L:m[1].toUpperCase(),code:this.key(m[1]+m[2])}));
      if(ts.length){
        const rec={}; for(const t of ts)if(!rec[t.L])rec[t.L]=t.code;
        records.push(rec);
      }
    }
    if(records.some(x=>Object.keys(x).length>=2))return records;
    const grouped=[]; let cur=null;
    for(const t of tokens){
      if(t.L==="A"){if(cur&&Object.keys(cur).length)grouped.push(cur);cur={A:t.code};}
      else if(cur&&!cur[t.L])cur[t.L]=t.code;
    }
    if(cur&&Object.keys(cur).length)grouped.push(cur);
    return grouped;
  }

  tupleKey(x){
    return ["A","G","C","D"].map(L=>x?.[L]||"").join("|");
  }

  extractFailureRecords(productAnalysis){
    let s=String(productAnalysis??"").replace(/\u00a0/g," ").trim();
    if(!s)return [];

    // PTI/GISC annotations can wrap onto the next visual line because of the
    // narrow Product Analysis field. Treat a standalone GISC line as an
    // annotation belonging to the immediately preceding failure, not as a
    // new failure and never as the annotation for the following failure.
    const annotations=[];
    s=s.replace(/\bGISC_[A-Za-z0-9_]+(?:\s+[A-Za-z0-9_]+)*_PTI\d*\b|\bGISC_[A-Za-z0-9_]+\b/gi,(m,body,offset)=>{
      annotations.push({token:m, pti:/_PTI\d*\b/i.test(m), index:offset});
      return ` __GISC_${annotations.length}__ `;
    });
    s=s.replace(/\b[A-G]\d{2,8}\b/gi," ");
    s=s.replace(/\b(the investigation will be conducted.*?)(?=(?:the following failures were identified|because|due to|[A-Z][^.!?]{2,80}\b(?:has|is|was|were|has a|has an)\b))/is," ");
    s=s.replace(/\bAs part of the evaluation,.*?(?=The following failures were identified:|Because|Due to|$)/is," ");
    s=s.replace(/\bThe following failures were identified:\s*/i," ");
    s=s.replace(/\bBased on the product analysis,.*$/is," ");

    const concrete=/\b(damage|damaged|crack|cracked|broken|break|worn|wear|peeled|peeling|scratch|scratched|kink|kinking|wrinkle|leak|leakage|restriction|blocked|blockage|foreign object|foreign objects|detached|separated|loose|cut|pinhole|swelled|swollen|malfunction|no image|poor image|noise|smear|adhesive|corrod|puncture|hole|fray|frayed|deform|deformation|fracture|split|tear|torn|snag|sticking|resistance|clogging|clogged|water tightness|water-tightness|image abnormality)\b/i;

    const raw=s.split(/(?:\.|;|\n)+/).map(x=>this.norm(x.replace(/^[-•\d.)]+\s*/,""))).filter(Boolean);
    const out=[];
    const attachAnnotation=(a)=>{
      if(!a)return;
      // A GISC/PTI code on its own wrapped line belongs to the preceding
      // failure. This is the key behavior for narrow UI/Excel line wrapping.
      if(out.length){
        out[out.length-1].ptiLinked=!!a.pti;
        out[out.length-1].ptiLinks=[a.token];
      }
    };

    for(let i=0;i<raw.length;i++){
      let chunk=raw[i];
      const markers=[...chunk.matchAll(/__GISC_(\d+)__/gi)];
      if(markers.length){
        const clean=this.norm(chunk.replace(/__GISC_\d+__/gi," "));
        // If the marker is the only content on this visual line, attach it
        // to the preceding failure and continue.
        if(!clean || !concrete.test(clean)){
          const a=annotations[Number(markers[0][1])-1];
          attachAnnotation(a);
          continue;
        }
        const a=annotations[Number(markers[0][1])-1];
        if(concrete.test(clean)){
          out.push({text:clean,ptiLinked:!!a?.pti,ptiLinks:a?[a.token]:[]});
          continue;
        }
      }

      if(!concrete.test(chunk)){
        // A wrapped continuation line can be part of the same failure.
        if(out.length && chunk.length>8 && !/^\d+[.)]\s*/.test(chunk)){
          out[out.length-1].text=this.norm(out[out.length-1].text+" "+chunk);
        }
        continue;
      }

      const rec={text:chunk,ptiLinked:false,ptiLinks:[]};
      const next=raw[i+1]||"";
      const nextMarker=/^__GISC_(\d+)__$/i.exec(next.trim());
      if(nextMarker){
        const a=annotations[Number(nextMarker[1])-1];
        rec.ptiLinked=!!a?.pti;
        rec.ptiLinks=a?[a.token]:[];
        i++;
      }
      out.push(rec);
    }

    const dedup=[]; const seen=new Set();
    for(const r of out){
      const key=this.normNarrative(r.text);
      if(key && !seen.has(key)){seen.add(key);dedup.push(r);}
    }
    return dedup.slice(0,30);
  }

  extractFailureTexts(productAnalysis){
    return this.extractFailureRecords(productAnalysis).map(x=>x.text);
  }

  getPredictor(){
    if(this.predictor)return this.predictor;
    try{
      const p=new DatasetPredictor();p.load();this.predictor=p;return p;
    }catch(e){return null;}
  }

  officialCandidates(query, annex, n=3){
    const key=`${annex}|${this.normNarrative(query)}|${n}`;
    if(this.officialCache.has(key))return this.officialCache.get(key);
    let out=[];
    try{out=this.imdrfStore?.ready ? this.imdrfStore.candidates(annex, query, n) : [];}catch(e){out=[];}
    this.officialCache.set(key,out); return out;
  }

  canonicalCode(code){
    const s=this.norm(code).replace(/[\s:\-]/g,"").toUpperCase();
    return s==="G050003"?"G05003":s;
  }

  topSemanticCandidates(text){
    const key=this.normNarrative(text);
    if(this.predictionCache.has(key))return this.predictionCache.get(key);
    const p=this.getPredictor();
    if(!p)return {dataset:{A:[],G:[],C:[],D:[]},holistic:null};
    const dataset={A:p.predict(text,"A",3),G:p.predict(text,"G",3),C:p.predict(text,"C",3),D:p.predict(text,"D",3)};
    const result={dataset,holistic:null};
    this.predictionCache.set(key,result); return result;
  }

  suggestARCode(eventDescription){
    const p=this.getPredictor();
    const dataset=p?p.predict(eventDescription,"A",5):[];
    const official=this.officialCandidates(eventDescription,"A",5);
    return dataset.map(x=>({
      ...x,
      source:"IMDRF Coding Examples",
      officialMatch:official.some(o=>this.canonicalCode(o.code)===this.canonicalCode(x.code))
    }));
  }

  suggestInvestigationCodes(failures){
    return failures.map(failure=>{
      const sem=this.topSemanticCandidates(failure);
      const result={failure,holistic:sem.holistic,dataset:sem.dataset};
      for(const L of ["A","G","C","D"]){
        result[L]=sem.dataset[L].map(x=>({
          code:this.canonicalCode(x.code),label:x.label,confidence:x.confidence,
          confidenceLevel:x.confidenceLevel,examples:x.examples||[]
        }));
        result[L+"_official"]=this.officialCandidates(failure,L,2);
      }
      return result;
    });
  }

  findBestTupleMatch(suggestion,actualTuples){
    if(!actualTuples.length)return {status:"REVIEW",score:0,confidence:0,actual:null};
    const weights={A:.45,G:.25,C:.20,D:.10};
    const predicted={};
    for(const L of ["A","G","C","D"]){
      predicted[L]=(suggestion[L]||[]).map(x=>this.canonicalCode(x.code)).filter(Boolean);
    }
    let best=null,bestScore=-1,bestDetails=null;
    for(const actual of actualTuples){
      let score=0,total=0;
      const details={};
      for(const L of ["A","G","C","D"]){
        const ac=this.canonicalCode(actual[L]||"");
        if(!ac)continue;
        total+=weights[L];
        const ranks=predicted[L];
        const rank=ranks.indexOf(ac);
        const letterScore=rank===0?1:rank===1?.82:rank===2?.65:0;
        score+=weights[L]*letterScore;
        details[L]={actual:ac,rank:rank>=0?rank+1:null,score:Math.round(letterScore*100)};
      }
      const normalized=total?score/total:0;
      if(normalized>bestScore){bestScore=normalized;best=actual;bestDetails=details;}
    }
    const semConfs=["A","G","C","D"].map(L=>suggestion[L]?.[0]?.confidence||0).filter(Boolean);
    const semanticConfidence=semConfs.length?Math.round(semConfs.reduce((a,b)=>a+b,0)/semConfs.length):0;
    const matchScore=Math.round(bestScore*100);
    const confidence=Math.min(99,Math.max(1,Math.round(.60*matchScore+.40*semanticConfidence)));
    let status="MISMATCH";
    if(matchScore>=95)status="PASS";
    else if(matchScore>=65)status="REVIEW";
    return {status,score:matchScore,confidence,actual:best,details:bestDetails,semanticConfidence};
  }

  /*
   * Event Description -> AR verification.
   * The coding examples is the primary evidence source and official
   * IMDRF terminology is a second independent terminology check.
   */
  verifyAR(eventDescription, arValue){
    const actualA=this.codeList(arValue,"A");
    const dataset=this.suggestARCode(eventDescription);
    const official=this.officialCandidates(eventDescription,"A",5);
    // AR is an A-code verification, but the same Event Description can
    // independently identify the affected component. Keep G separate so
    // the UI can show the related component recommendation without treating
    // G as part of the AR code itself.
    const predictor=this.getPredictor();
    const gDataset=predictor?predictor.predict(eventDescription,"G",5):[];
    const gOfficial=this.officialCandidates(eventDescription,"G",5);
    const top=dataset[0]||null;
    const officialTop=official[0]||null;
    const actualSet=new Set(actualA);
    const datasetMatch=!!top&&actualSet.has(this.canonicalCode(top.code));
    const officialMatch=!!officialTop&&actualSet.has(this.canonicalCode(officialTop.code));
    const anyDataset=dataset.some(x=>actualSet.has(this.canonicalCode(x.code)));
    const anyOfficial=official.some(x=>actualSet.has(this.canonicalCode(x.code)));
    const evidence=[];
    if(datasetMatch)evidence.push("coding examples top candidate");
    if(officialMatch)evidence.push("official IMDRF top terminology");
    const semanticConfidence=Math.round(
      ((top?.confidence||0)+(officialTop?.confidence||0))/((top?1:0)+(officialTop?1:0)||1)
    );
    const matchConfidence=datasetMatch&&officialMatch
      ?Math.min(99,Math.round(.55*semanticConfidence+45))
      :datasetMatch||officialMatch
        ?Math.min(94,Math.round(.65*semanticConfidence+25))
        :Math.max(1,Math.round(.55*semanticConfidence));
    let status="FAIL";
    if(datasetMatch&&officialMatch)status="PASS";
    else if(anyDataset||anyOfficial)status="REVIEW";
    return {
      status,actual:actualA,eventDescription,
      dataset,official,gDataset,gOfficial,top,officialTop,
      datasetMatch,officialMatch,anyDataset,anyOfficial,
      semanticConfidence,matchConfidence,evidence
    };
  }

  /*
   * Product Analysis failure -> AI (As Investigated) verification.
   * AI is evaluated against the actual A/G/C/D tuples, while the suggestion
   * comes from the full coding examples and is cross-checked with official
   * IMDRF 2026 terminology.
   */
  verifyAI(productAnalysis, aiValue){
    const failures=this.extractFailureTexts(productAnalysis);
    const actualTuples=this.parseCodingTuples(aiValue);
    const items=[];
    for(const failure of failures){
      const suggestion=this.suggestInvestigationCodes([failure])[0];
      const match=this.findBestTupleMatch(suggestion,actualTuples);
      const official={};
      for(const L of ["A","G","C","D"])official[L]=suggestion[L+"_official"]||[];
      items.push({failure,suggestions:{A:suggestion.A,G:suggestion.G,C:suggestion.C,D:suggestion.D},official,match});
    }
    return {available:!!(failures.length&&actualTuples.length),failures,actualTuples,items};
  }

  evaluateCO(r){
    const L=this.norm(r.logic).toLowerCase();
    const f=this.names(r.fieldsReferenced);
    const t=this.text("complaint")||this.allText();

    const simple={
      "CO-006":[["Communication Channel"],["Email","Phone","Website","Post","Fax","Face-to-face"]],
      "CO-007":[["Language"]],
      "CO-009":[["Country of Occurrence"]],
      "CO-010":[["Reporter Phone"]],
      "CO-011":[["Reporter Email"]],
      "CO-012":[["Reporter Occupation"]],
      "CO-013":[["Customer Name"]],
      "CO-014":[["Customer Address"]],
      "CO-015":[["Due Diligence Contact Occupation"]],
      "CO-017":[["Product Lot/Serial Number"]]
    };
    if(r.id==="CO-005") {
      const hcp=this.field(t,["Reporter is Healthcare Professional?","Complaint: Reporter is Healthcare Professional?"]);
      const email=this.field(t,["Reporter Email","Complaint: Reporter Email"]);
      const source=this.field(t,["Report Source","Complaint: Report Source"]);
      if(!hcp.found||!email.found||!source.found) {
        return this.result(r,"REVIEW","Reporter, Healthcare Professional flag, Reporter Email, or Report Source could not be located.","Verify all referenced Reporter and Report Source fields.");
      }
      const hv=this.key(hcp.value);
      const isHCP=(hv==="y");
      const ev=this.norm(email.value).toLowerCase();
      const isOlympusEmail=/@olympus(?:\.[a-z]{2,}(?:\.[a-z]{2,})?)?/i.test(ev);
      // Healthcare Professional classification takes precedence when explicitly Yes.
      const expected=isHCP?"Healthcare Professional":(isOlympusEmail?"Company Representative":"User Facility");
      const sourceKey=this.key(source.value);
      const present=sourceKey===this.key(expected)||sourceKey.includes(this.key(expected))||(isHCP&&(sourceKey.includes("health professional")||sourceKey.includes("healthcare professional")));
      if(present) {
        return this.result(r,"PASS",`Report Source contains ${expected}, which matches the reporter classification.`,"",{current:source.value,expected});
      }
      return this.result(r,"REVIEW",`Report Source should contain ${expected} based on the Reporter information.`,`Add ${expected} to Complaint: Report Source.`,{current:source.value,expected});
    }

    if(simple[r.id]){
      const [names,allowed]=simple[r.id];
      if(allowed)return this.allowed(r,names,allowed);
      const x=this.field(t,names);
      return !x.found?this.result(r,"REVIEW",`Could not locate ${names[0]}.`,`Verify ${names[0]} is populated.`)
        :this.empty(x.value)?this.result(r,"FAIL",`${x.label} is blank.`,`Populate ${x.label}.`):this.result(r,"PASS",`${x.label} is populated.`,"",{current:x.value});
    }

    if(r.id==="CO-002"){
      const p=this.field(t,["Product"]), m=this.field(t,["Model Number","Complaint: Model Number"]);
      if(!p.found||!m.found||this.empty(p.value)||this.empty(m.value))
        return this.result(r,"FAIL","Product or Model Number is blank.","Populate Product and Model Number.");
      return this.key(p.value).includes(this.key(m.value))
        ?this.result(r,"PASS","Product contains the Model Number.","",{current:p.value,expected:m.value})
        :this.result(r,"FAIL","Product does not contain the Model Number.","Correct Product or Model Number.",{current:p.value,expected:m.value});
    }

    if(r.id==="CO-003"){
      const a=this.field(t,["Assigned To"]), b=this.field(t,["Complaint: Assigned To"]);
      if(!a.found||!b.found)return this.result(r,"REVIEW","Assigned owner fields could not be located.","Verify Assigned To and Complaint: Assigned To.");
      if(this.empty(a.value)||this.empty(b.value))return this.result(r,"N/A","Assigned owner is blank; consistency comparison is not applicable.","");
      return this.key(a.value)===this.key(b.value)
        ?this.result(r,"PASS","Assigned To matches Complaint: Assigned To.","",{current:b.value,expected:a.value})
        :this.result(r,"FAIL","Assigned To does not match Complaint: Assigned To.",`Correct Complaint: Assigned To to ${a.value}.`,{current:b.value,expected:a.value});
    }

    if(r.id==="CO-004"){
      const req=this.field(t,["Complaint: Customer Letter Required by Customer?"]);
      const att=this.field(t,["Complaint: Customer Letter Attached?"]);
      const date=this.field(t,["Complaint: Customer Letter Sent Date"]);
      if(!req.found)return this.result(r,"N/A","Customer Letter Required is blank; this check is not applicable.","");
      const q=this.key(req.value), attached=att.found&&this.key(att.value)==="yes", sent=date.found&&!this.empty(date.value);
      if(q==="no")return !sent
        ?this.result(r,"PASS",'Customer Letter Required = "No" and Sent Date is blank.',"")
        :this.result(r,"FAIL",'Customer Letter Required = "No" but Sent Date is populated.',"Clear Customer Letter Sent Date.");
      if(q==="yes")return attached&&sent
        ?this.result(r,"PASS",'Customer Letter Required = "Yes", Attached = "Yes", and Sent Date is populated.',"")
        :this.result(r,"FAIL",'Customer Letter Required = "Yes" but Attached and/or Sent Date is inconsistent.',"Set Attached = Yes and populate Sent Date.");
      return this.result(r,"REVIEW","Customer Letter Required has an unexpected value.","Verify Yes, No, or blank.",{current:req.value});
    }

    if(r.id==="CO-008"){
      const d=this.field(t,["Date of Event","Complaint: Date of Event"]);
      const u=this.field(t,["Date of Event Unknown","Complaint: Date of Event Unknown"]);
      if(!d.found||!u.found)return this.result(r,"REVIEW","Date of Event or Unknown checkbox could not be located.","Verify both fields.");
      const blank=this.empty(d.value), checked=["true","yes","1"].includes(this.key(u.value));
      return ((blank&&checked)||(!blank&&!checked))
        ?this.result(r,"PASS","Date of Event and Unknown checkbox are consistent.","")
        :this.result(r,"FAIL","Date of Event and Unknown checkbox are inconsistent.","Use Unknown=checked when Date of Event is blank; otherwise leave Unknown unchecked.",{current:`Date=${d.value}; Unknown=${u.value}`});
    }

    if(r.id==="CO-016"){
      const typ=this.field(t,["US MDR Type of Reportable Event","Complaint: US MDR Type of Reportable Event"]);
      const md=this.field(t,["Manufacture Date","Complaint: Manufacture Date"]);
      if(!typ.found||!md.found)return this.result(r,"REVIEW","US MDR Type or Manufacture Date could not be located.","Verify both fields.");
      const reportable=["malfunction","reportable","seriousinjury"].includes(this.key(typ.value));
      if(!reportable)return this.result(r,"N/A","Manufacture Date is not conditionally required for this event type.","");
      return !this.empty(md.value)
        ?this.result(r,"PASS","Manufacture Date is populated for the reportable event type.","")
        :this.result(r,"FAIL","Manufacture Date is required for the reportable event type.","Populate Manufacture Date.");
    }

    if(r.id==="CO-018"){
      const lot=this.field(t,["Product Lot / Serial Number","Product Lot/Serial Number","Complaint: Product Lot / Serial Number"]);
      const unk=this.field(t,["Product Lot/Serial Number Unknown","Complaint: Product Lot/Serial Number Unknown"]);
      if(!lot.found||!unk.found)return this.result(r,"REVIEW","Lot/Serial Number or Unknown checkbox could not be located.","Verify both fields.");
      const blank=this.empty(lot.value), checked=["true","yes","1"].includes(this.key(unk.value));
      return ((blank&&checked)||(!blank&&!checked))
        ?this.result(r,"PASS","Product Lot/Serial Number and Unknown checkbox are consistent.","")
        :this.result(r,"FAIL","Product Lot/Serial Number and Unknown checkbox are inconsistent.","Check Unknown only when Lot/Serial Number is blank.",{current:`Lot=${lot.value}; Unknown=${unk.value}`});
    }

    if(r.id==="CO-019"){
      const q=this.field(t,["Qty Affected","Complaint: Qty Affected"]);
      if(!q.found||this.empty(q.value))return this.result(r,"FAIL","Qty Affected is blank.","Populate Qty Affected with a number >= 1.");
      const n=Number(String(q.value).replace(/,/g,""));
      return Number.isFinite(n)&&n>=1
        ?this.result(r,"PASS","Qty Affected is a valid number >= 1.","",{current:q.value})
        :this.result(r,"FAIL","Qty Affected must be a number >= 1.","Correct Qty Affected.",{current:q.value,expected:">= 1"});
    }

    // Exact conditional rules supplied by the user.
    if(r.id==="CO-020"){
      const dt=this.field(t,["Device Type","Complaint: Device Type"]);
      const usage=this.field(t,["Usage of Device","Complaint: Usage of Device"]);
      const recycled=this.field(t,["Is this a Recycled Single Use Device","Is this a recycled single-use device?","Complaint: Is this a recycled single-use device?"]);
      if(!dt.found||!usage.found||!recycled.found)
        return this.result(r,"REVIEW","Device Type, Usage of Device, or Recycled Single Use Device could not be located.","Verify all three referenced fields.");
      const d=this.key(dt.value), u=this.key(usage.value), rv=this.key(recycled.value);
      // User-supplied rule: Reuse Device Type -> Recycled Single-Use = No.
      if(d.includes("reuse")){
        return rv==="no"
          ?this.result(r,"PASS","Device Type is Reuse and Recycled Single-Use Device is No.","",{current:`Device Type=${dt.value}; Usage=${usage.value}; Recycled Single-Use=${recycled.value}`,expected:"Reuse → No"})
          :this.result(r,"FAIL","Device Type is Reuse but Recycled Single-Use Device is not No.","Set Is this a recycled single-use device? = No.",{current:`Device Type=${dt.value}; Usage=${usage.value}; Recycled Single-Use=${recycled.value}`,expected:"Reuse → No"});
      }
      // User-supplied rule: Single Use Device Type -> inspect Usage; Reuse -> Yes.
      if(d.includes("singleuse")||d.includes("single")){
        if(u.includes("reuse")){
          return rv==="yes"
            ?this.result(r,"PASS","Device Type is Single Use, Usage of Device is Reuse, and Recycled Single-Use Device is Yes.","",{current:`Device Type=${dt.value}; Usage=${usage.value}; Recycled Single-Use=${recycled.value}`,expected:"Single Use + Reuse → Yes"})
            :this.result(r,"FAIL","Device Type is Single Use and Usage of Device is Reuse, but Recycled Single-Use Device is not Yes.","Set Is this a recycled single-use device? = Yes.",{current:`Device Type=${dt.value}; Usage=${usage.value}; Recycled Single-Use=${recycled.value}`,expected:"Single Use + Reuse → Yes"});
        }
        return this.result(r,"N/A","Device Type is Single Use, but Usage of Device is not Reuse; the supplied rule does not define a required Yes/No outcome for this combination.","No change from this rule; review if another business rule applies.",{current:`Device Type=${dt.value}; Usage=${usage.value}; Recycled Single-Use=${recycled.value}`,expected:"Only Single Use + Usage=Reuse is defined"});
      }
      return this.result(r,"N/A","Device Type is neither Reuse nor Single Use; the supplied recycled-device rule does not define an outcome.","Review Device Type if needed.",{current:`Device Type=${dt.value}; Usage=${usage.value}; Recycled Single-Use=${recycled.value}`});
    }

    if(r.id==="CO-021"){
      return this.allowed(r,["Culture Test Positive"],["Yes","No","No Information","ASKU","Refused","Asked but unknown"]);
    }
    // Additional CO verifications supplied in the process sheet.
    if(r.id==="CO-022"){
      // Verify Investigation Classification — use only the exact referenced field.
      const x=this.field(t,["Investigation Classification"]);
      if(!x.found||this.empty(x.value)){
        return this.result(r,"FAIL","Investigation Classification is blank.","Set Investigation Classification to Pathway1 or Pathway2.",{current:x.found?x.value:"Blank",expected:"Pathway1 or Pathway2"});
      }
      const valid=/^pathway\s*(1|2)$/i.test(this.norm(x.value));
      return valid
        ?this.result(r,"PASS","Investigation Classification is Pathway1 or Pathway2.","",{current:x.value,expected:"Pathway1 or Pathway2"})
        :this.result(r,"FAIL","Investigation Classification must be Pathway1 or Pathway2.","Set Investigation Classification to Pathway1 or Pathway2.",{current:x.value,expected:"Pathway1 or Pathway2"});
    }
    if(r.id==="CO-023"){
      const a=this.field(t,["Customer Letter Attached?"]), d=this.field(t,["Customer Letter Sent Date"]), req=this.field(t,["Customer Letter Required by Customer?"]);
      if(!a.found&&!d.found)return this.result(r,"REVIEW","Customer Letter Attached/Sent Date fields could not be located.","Verify both fields.");
      if(/^yes$/i.test(a.value))return !this.empty(d.value)?this.result(r,"PASS","Customer Letter is attached and Sent Date is populated.",""):this.result(r,"FAIL","Customer Letter is attached but Sent Date is blank.","Populate Customer Letter Sent Date.");
      if(req.found&&/^no$/i.test(req.value))return this.empty(d.value)?this.result(r,"PASS","Customer Letter is not required and Sent Date is blank.",""):this.result(r,"FAIL","Customer Letter is not required but Sent Date is populated.","Clear Customer Letter Sent Date.");
      return this.result(r,"FAIL","Customer Letter Sent Date is not consistent with the attachment status.","If Attached = Yes, populate Sent Date; if not required, keep Sent Date blank.");
    }
    if(r.id==="CO-024"){
      const src=this.field(t,["Report Source","Complaint: Report Source"]);
      const oth=this.field(t,["Report Source (Other)","Complaint: Report Source (Other)"]);
      if(!src.found||!oth.found)return this.result(r,"REVIEW","Complaint: Report Source or Complaint: Report Source (Other) could not be located.","Verify both fields.");
      const sourceKey=this.key(src.value);
      const isOther=sourceKey==="other"||sourceKey==="others";
      // CO-024 only imposes a requirement when Report Source is Other/Others.
      // For every other Report Source value, the rule passes without requiring
      // Report Source (Other) to be populated.
      if(!isOther) return this.result(r,"PASS",'Report Source is not Other/Others; CO-024 requirement does not apply.',"",{current:`Report Source=${src.value}; Report Source (Other)=${oth.value}`,expected:"PASS"});
      return !this.empty(oth.value)
        ?this.result(r,"PASS",'Report Source is Other/Others and Report Source (Other) is populated.',"",{current:`Report Source=${src.value}; Report Source (Other)=${oth.value}`,expected:"Report Source (Other) populated"})
        :this.result(r,"FAIL",'If Report Source is Other/Others, Report Source (Other) must not be blank.',"Populate Complaint: Report Source (Other) when Report Source is Other/Others.",{current:`Report Source=${src.value}; Report Source (Other)=${oth.value}`,expected:"Report Source (Other) populated"});
    }
    if(r.id==="CO-025"){
      const x=this.field(t,["Device Operator"]); if(!x.found||this.empty(x.value))return this.result(r,"FAIL","Device Operator is blank.","Populate Device Operator or use Health Professional.");
      return /health professional/i.test(x.value)||!this.empty(x.value)?this.result(r,"PASS","Device Operator is populated.",""):this.result(r,"FAIL","Device Operator is invalid.","Use Health Professional or retain the existing valid value.");
    }
    // CO-029 — Verify Patient Outcome.
    // Rule applies only when Event Occurred At is one of the specified conditions.
    // NI / No Information is treated as PASS, and Patient Outcome = N/A is PASS.
    // Any other Event Occurred At outside the specified set is also PASS.
    if(r.id==="CO-029") {
      const at=this.field(t,["Event Occurred At","Complaint: Event Occurred At"]);
      const v=this.field(t,["Patient Outcome","Complaint: Patient Outcome"]);
      if(!at.found||!v.found) return this.result(r,"REVIEW","Event Occurred At and Patient Outcome could not both be located.","Verify both referenced fields.");
      const A=this.key(at.value);
      const V=this.key(v.value);
      const isNI=A==="ni";
      const isNAOutcome=V==="na";
      const specified=/^(reprocessing|service|maintenance|installation|outofboxfailure|duringsetup|inspectionforuse|servicemaintenancenotinaclinicalsetting)$/.test(A);
      if(isNI) return this.result(r,"PASS","Event Occurred At is NI / No Information; CO-029 passes without enforcing Patient Outcome = None.","",{current:`Event Occurred At=${at.value}; Patient Outcome=${v.value}`,expected:"PASS"});
      if(isNAOutcome) return this.result(r,"PASS","Patient Outcome is N/A; CO-029 passes.","",{current:`Event Occurred At=${at.value}; Patient Outcome=${v.value}`,expected:"PASS"});
      if(!specified) return this.result(r,"PASS","Event Occurred At is outside the specified conditional set; CO-029 passes.","",{current:`Event Occurred At=${at.value}; Patient Outcome=${v.value}`,expected:"PASS"});
      const pass=V==="none";
      return pass
        ?this.result(r,"PASS","Patient Outcome is None for the specified Event Occurred At value.","",{current:`Event Occurred At=${at.value}; Patient Outcome=${v.value}`,expected:"Patient Outcome=None"})
        :this.result(r,"FAIL","Patient Outcome must be None for the specified Event Occurred At value.","Set Complaint: Patient Outcome to None.",{current:`Event Occurred At=${at.value}; Patient Outcome=${v.value}`,expected:"Patient Outcome=None"});
    }
    const procRules={
      "CO-026":["Procedure Name"],"CO-027":["Procedure Outcome"],"CO-028":["Procedure Type"],"CO-030":["When during Procedure did event occur?"]
    };
    if(procRules[r.id]){
      const at=this.field(t,["Event Occurred At"]), v=this.field(t,procRules[r.id]);
      if(!at.found||!v.found)return this.result(r,"REVIEW","Event Occurred At and the dependent procedure field could not both be located.","Verify both referenced fields.");
      const A=this.key(at.value).replace(/noinformationavailable|noinformation/g,"ni"), V=this.key(v.value).replace(/noinformationavailable|noinformation/g,"ni");
      let ok=false;
      if(/reprocessing|service|maintenance|installation|outofboxfailure|duringsetup|inspectionforuse/.test(A))ok=this.key(v.value)==="na";
      else if(/askedbutunknown/.test(A))ok=/^(ni|askedbutunknown)$/.test(V);
      else if(/^ni$/.test(A))ok=V==="ni";
      else if(/^procedure$/.test(A))ok=!this.empty(v.value)&&/^(ni|askedbutunknown)$/.test(V)===false;
      return ok?this.result(r,"PASS",`${procRules[r.id][0]} is consistent with Event Occurred At.`,"",{current:v.value,expected:at.value})
        :this.result(r,"FAIL",`${procRules[r.id][0]} is inconsistent with Event Occurred At.`,"Correct the dependent value using the Event Occurred At rule.",{current:v.value,expected:at.value});
    }
    if(r.id==="CO-031"){
      const at=this.field(t,["Event Occurred At"]), v=this.field(t,["Event Occurred At"]);
      return at.found&&!this.empty(v.value)?this.result(r,"PASS","Event Occurred At is populated.","",{current:v.value}):this.result(r,"FAIL","Event Occurred At is blank.","Populate Event Occurred At.");
    }
    if(r.id==="CO-032"){
      const x=this.field(t,["Item Code"]), details=this.field(t,["Product Summary"]);
      if(!x.found||!details.found)return this.result(r,"REVIEW","Item Code or Product Summary could not be verified.","Verify Item Code against Product Details.");
      return this.key(details.value).includes(this.key(x.value))?this.result(r,"PASS","Item Code matches Product Summary details.",""):this.result(r,"FAIL","Item Code does not match Product Summary details.","Correct Item Code or Product Summary.",{current:x.value,expected:details.value});
    }
    if(r.id==="CO-033"){
      const x=this.field(t,["Product Family"]), details=this.field(t,["Product Summary"]);
      if(!x.found||!details.found)return this.result(r,"REVIEW","Product Family or Product Summary could not be verified.","Verify Product Family against Product Details.");
      return this.key(details.value).includes(this.key(x.value))?this.result(r,"PASS","Product Family matches Product Summary details.",""):this.result(r,"FAIL","Product Family does not match Product Summary details.","Correct Product Family or Product Summary.",{current:x.value,expected:details.value});
    }
    if(r.id==="CO-034"){ const typ=this.field(t,["US MDR Type of Reportable Event","Complaint: US MDR Type of Reportable Event"]); const md=this.field(t,["Manufacture Date","Complaint: Manufacture Date"]); if(!typ.found||!md.found)return this.result(r,"REVIEW","US MDR Type or Manufacture Date could not be located.","Verify both fields."); const reportable=["malfunction","reportable","seriousinjury"].includes(this.key(typ.value)); if(!reportable)return this.result(r,"N/A","Manufacture Date is not conditionally required for this event type.",""); return !this.empty(md.value)?this.result(r,"PASS","Manufacture Date is populated for the reportable event type.",""):this.result(r,"FAIL","Manufacture Date is required for the reportable event type.","Populate Manufacture Date."); }
    if(r.id==="CO-035"){
      const ev=this.field(t,["Event Description"]), af=this.field(t,["Asset Flag"]); if(!af.found)return this.result(r,"REVIEW","Asset Flag could not be located.","Verify Asset Flag.");
      const trigger=/\bPM\b|asset return/i.test(ev.value||"");
      const yes=/^(yes|true|1)$/i.test(af.value), no=/^(no|false|0)$/i.test(af.value);
      return trigger?(yes?this.result(r,"PASS","Asset Flag is True/Yes as required by the Event Description.",""):this.result(r,"FAIL","Event Description indicates PM/Asset Return but Asset Flag is not True.","Set Asset Flag to True.")):(no?this.result(r,"PASS","Asset Flag is False/No and no PM/Asset Return trigger was found.",""):this.result(r,"FAIL","No PM/Asset Return trigger was found, so Asset Flag should be False.","Set Asset Flag to False."));
    }
    if(r.id==="CO-036"){
      const ev=this.field(t,["Event Description"]), po=this.field(t,["Procedure Outcome"]), x=this.field(t,["Were other devices involved in event?"]); if(!x.found)return this.result(r,"REVIEW","Other Devices Involved field could not be located.","Verify the field.");
      const multiple=/\b(two|multiple|another|competitor|other device|different device)\b/i.test(ev.value||"");
      const competitor=/competitor/i.test(po.value||""); const yes=/^yes$/i.test(x.value), no=/^no$/i.test(x.value);
      return (multiple&&competitor)?(yes?this.result(r,"PASS","Multiple-device/competitor evidence is consistent with Yes.",""):this.result(r,"FAIL","Event/Procedure indicates another or competitor device, but Other Devices Involved is not Yes.","Set Other Devices Involved = Yes.")):(no?this.result(r,"PASS","No multiple-device trigger was detected and Other Devices Involved is No.",""):this.result(r,"FAIL","Other Devices Involved should be No when no multiple-device trigger is present.","Set Other Devices Involved = No."));
    }
    if(r.id==="CO-037"){
      const exp=this.field(t,["Product Return Expected"]), avail=this.field(t,["Device available for evaluation?"]); if(!avail.found)return this.result(r,"REVIEW","Device available for evaluation field could not be located.","Verify it is Yes or No.");
      if(!/^(yes|no)$/i.test(avail.value))return this.result(r,"FAIL","Device available for evaluation must be Yes or No.","Set Device available for evaluation to Yes or No.");
      if(/fse|ess/i.test(this.norm(t))&&!/^yes$/i.test(avail.value))return this.result(r,"FAIL","FSE/ESS case requires Device available for evaluation = Yes.","Set Device available for evaluation = Yes.");
      if(exp.found&&!this.empty(exp.value) && /^yes$/i.test(exp.value) && !/^yes$/i.test(avail.value))return this.result(r,"FAIL","Product Return Expected is Yes but Device available for evaluation is not Yes.","Set Device available for evaluation = Yes when Product Return Expected is Yes.");
      if(exp.found&&!this.empty(exp.value) && /^no$/i.test(exp.value) && !/^no$/i.test(avail.value))return this.result(r,"FAIL","Product Return Expected is No but Device available for evaluation is not No.","Align Device available for evaluation with Product Return Expected.");
      return this.result(r,"PASS","Device available for evaluation is valid and aligned with Product Return Expected.","");
    }
    if(r.id==="CO-038"){
      const ret=this.field(t,["Product Returned Date","Complaint: Product Returned Date"]);
      const status=this.field(t,["Product Return Status","Complaint: Product Return Status"]);
      if(!ret.found||!status.found)return this.result(r,"REVIEW","Product Returned Date or Product Return Status could not be located.","Verify both fields.");
      if(!this.empty(ret.value)){
        return this.key(status.value)==="released"
          ?this.result(r,"PASS","Product Returned Date is populated and Product Return Status = Released.","",{current:status.value,expected:"Released"})
          :this.result(r,"FAIL","Product Returned Date is populated but Product Return Status is not Released.","Set Product Return Status = Released.",{current:status.value,expected:"Released"});
      }
      return this.result(r,"N/A","Product Returned Date is blank; the Released-status condition is not triggered.","",{current:ret.value});
    }

    if(r.id==="CO-039"){
      const death=this.field(t,["Was there a Death?","Complaint: Was there a Death?"]);
      const outcome=this.field(t,["Patient Outcome","Complaint: Patient Outcome"]);
      if(!death.found||!outcome.found)return this.result(r,"REVIEW","Death or Patient Outcome could not be located.","Verify both fields.");
      const isDeath=this.key(outcome.value)==="death", deathYes=this.key(death.value)==="yes", deathBlank=this.empty(death.value);
      return (isDeath?(deathYes||deathBlank):!deathYes)
        ?this.result(r,"PASS","Was There A Death is consistent with Patient Outcome.","",{current:`Death=${death.value}; Outcome=${outcome.value}`})
        :this.result(r,"FAIL","Was There A Death is inconsistent with Patient Outcome.","Set Was There A Death = Yes when Patient Outcome = Death; otherwise do not mark it Yes.",{current:`Death=${death.value}; Outcome=${outcome.value}`});
    }

    if(r.id==="CO-040"){
      const p=this.field(t,["Patient Outcome","Complaint: Patient Outcome"]);
      const at=this.field(t,["Event Occurred At","Complaint: Event Occurred At"]);
      const x=this.field(t,["Was the procedure prolonged...","Complaint: Was the procedure prolonged..."]);
      if(!p.found||!at.found||!x.found)return this.result(r,"REVIEW","Procedure Prolonged dependencies could not all be located.","Verify Patient Outcome, Event Occurred At and Procedure Prolonged.");
      const pk=this.key(p.value), ak=this.key(at.value), xk=this.key(x.value);
      if(pk==="proceduredelay")return /less30|lessthan30|greaterthanorequalto30|30mins/.test(xk)
        ?this.result(r,"PASS","Procedure Delay has a valid prolonged-procedure value.","")
        :this.result(r,"FAIL","Patient Outcome = Procedure Delay but Procedure Prolonged is not a valid duration.","Select less than 30 mins or greater than or equal to 30 mins.");
      if(["reprocessing","service","maintenance","installation","outofboxfailure","duringsetup","inspectionforuse"].some(v=>ak.includes(v)))
        return xk==="na"?this.result(r,"PASS","Procedure Prolonged is N/A for this Event Occurred At value.",""):this.result(r,"FAIL","Procedure Prolonged should be N/A for this Event Occurred At value.","Set Procedure Prolonged = NA.");
      if(ak==="askedbutunknown")return ["ni","askedbutunknown"].includes(xk)?this.result(r,"PASS","Procedure Prolonged is consistent with Asked but unknown.",""):this.result(r,"FAIL","Procedure Prolonged is inconsistent with Asked but unknown.","Use NI or Asked but unknown.");
      if(ak==="ni")return xk==="ni"?this.result(r,"PASS","Procedure Prolonged is consistent with NI / No Information.",""):this.result(r,"FAIL","Procedure Prolonged should be NI / No Information when Event Occurred At is NI / No Information.","Set Procedure Prolonged = NI / No Information.");
      if(ak==="procedure")return ["ni","askedbutunknown"].includes(xk)||!this.empty(x.value)?this.result(r,"PASS","Procedure Prolonged is populated/unknown as permitted for a Procedure event.",""):this.result(r,"FAIL","Procedure Prolonged is inconsistent with the Event Occurred At rule.","Correct Procedure Prolonged.");
      return this.result(r,"REVIEW","The Event Occurred At value does not match a supplied conditional branch.","Verify the Procedure Prolonged value against the source process rule.",{current:x.value});
    }

    if(r.id==="CO-041"){
      const x=this.field(t,["Any (suspected) patient infection?","Complaint: Any (suspected) patient infection?"]);
      const ev=this.field(t,["Event Description","Complaint: Event Description"]);
      if(!x.found)return this.result(r,"REVIEW","Patient infection field could not be located.","Verify patient infection against complaint information.");
      const trigger=/infection|infected|sepsis|contamination/i.test(ev.value||"");
      return trigger?( /^yes$/i.test(x.value)?this.result(r,"PASS","Complaint indicates infection and Patient Infection is Yes.",""):this.result(r,"FAIL","Complaint indicates possible infection but Patient Infection is not Yes.","Set Patient Infection = Yes when supported by the complaint.")):(this.empty(x.value)?this.result(r,"FAIL","Patient Infection is blank.","Populate Patient Infection."):this.result(r,"PASS","Patient Infection is populated and no infection trigger was detected.",""));
    }

    if(r.id==="CO-042"){
      const ai=this.field(t,["AI Codes","Complaint: AI Codes"]);
      const inv=this.field(t,["Complaint Codes - Investigation","Complaint: Complaint Codes - Investigation"]);
      const allCodes=this.field(t,["Complaint Codes","Complaint: Complaint Codes"]);
      const pa=this.field(t,["Product Analysis","Complaint: Product Analysis"]);

      if(!ai.found)return this.result(r,"REVIEW","AI Codes could not be located.","Verify AI Codes against Product Analysis failures and the As Investigated coding records.");
      const actual=this.parseCodingTuples(ai.value);
      if(!actual.length)return this.result(r,"FAIL","AI Codes contains no structured A/G/C/D coding record.","Populate AI Codes with the applicable As Investigated A/G/C/D coding.");

      // Preserve the deterministic traceability check when a dedicated
      // Investigation coding field is present.
      const invActual=this.parseCodingTuples(inv.found?inv.value:"");
      const fallbackActual=this.parseCodingTuples(allCodes.found?allCodes.value:"");
      const invComplete=invActual.filter(x=>x.A&&x.G&&x.C&&x.D);
      // The consolidated Complaint Codes field is not a reliable one-to-one
      // AI tuple source, so it is used only as contextual evidence, not for
      // rejecting otherwise valid AI tuples.
      const referenceRecords=invComplete;
      const unsupported=referenceRecords.length
        ?actual.filter(x=>!referenceRecords.some(c=>this.tupleKey(c)===this.tupleKey(x)))
        :[];

      const verification=this.verifyAI(pa.found?pa.value:"",ai.value);
      const items=verification.items||[];
      const mismatches=items.filter(x=>x.match.status==="MISMATCH");
      const reviews=items.filter(x=>x.match.status==="REVIEW");
      const passes=items.filter(x=>x.match.status==="PASS");

      if(!verification.failures.length){
        return this.result(r,"REVIEW","AI Codes are populated, but no Product Analysis failure description could be isolated for failure-specific semantic verification.","Verify the Product Analysis failure descriptions and review the AI A/G/C/D codes manually.",{
          current:ai.value,verification
        });
      }

      if(unsupported.length){
        return this.result(r,"FAIL",`AI Codes contains ${unsupported.length} coding record(s) that do not match the available As Investigated coding records.`,
          "Correct AI Codes so every AI A/G/C/D tuple is traceable to the As Investigated coding record.",{
            current:ai.value,expected:inv.found?inv.value:(allCodes.found?allCodes.value:""),
            verification
          });
      }

      if(mismatches.length){
        return this.result(r,"FAIL",`${mismatches.length} Product Analysis failure(s) do not match their AI A/G/C/D coding suggestions.`,
          "Review the failure-specific IMDRF suggestions and correct the AI coding where supported by the Product Analysis and official terminology.",{
            current:ai.value,verification,
            suggestions:items.map(x=>({
              failure:x.failure,
              A:x.suggestions.A,G:x.suggestions.G,C:x.suggestions.C,D:x.suggestions.D,
              match:x.match,
              official:x.official
            }))
          });
      }

      if(reviews.length){
        return this.result(r,"REVIEW",`${reviews.length} Product Analysis failure(s) have only a partial AI-code match and require human review.`,
          "Confirm the suggested A/G/C/D codes against the Product Analysis and official IMDRF terminology before acceptance.",{
            current:ai.value,verification,
            suggestions:items.map(x=>({
              failure:x.failure,
              A:x.suggestions.A,G:x.suggestions.G,C:x.suggestions.C,D:x.suggestions.D,
              match:x.match,
              official:x.official
            }))
          });
      }

      const avgConfidence=passes.length
        ?Math.round(passes.reduce((a,x)=>a+(x.match.confidence||0),0)/passes.length):0;
      return this.result(r,"PASS",`All ${passes.length} Product Analysis failure(s) have matching AI A/G/C/D coding. Average match confidence: ${avgConfidence}%.`,
        "",{
          current:ai.value,verification,
          confidence:avgConfidence,
          suggestions:items.map(x=>({
            failure:x.failure,
            A:x.suggestions.A,G:x.suggestions.G,C:x.suggestions.C,D:x.suggestions.D,
            match:x.match,
            official:x.official
          }))
        });
    }

    if(r.id==="CO-043"){
      const ar=this.field(t,["AR Codes","Complaint: AR Codes"]);
      const ev=this.field(t,["Event Description","Complaint: Event Description"]);
      if(!ar.found)return this.result(r,"REVIEW","AR Codes could not be located.","Verify the reported A-code against Event Description, the IMDRF Coding Examples and official IMDRF terminology.");
      if(!ev.found||this.empty(ev.value))return this.result(r,"REVIEW","Event Description is unavailable for AR semantic validation.","Verify the Event Description before accepting AR coding.");

      const verification=this.verifyAR(ev.value,ar.value);
      if(!verification.actual.length)
        return this.result(r,"FAIL","AR Codes contains no A-code.","Populate the appropriate IMDRF As Reported A-code.");

      const best=verification.top||verification.officialTop;
      const expected=best?`${best.code} — ${best.label}`:"No supported candidate";
      const sourceText=verification.evidence.length?` Evidence: ${verification.evidence.join(" + ")}.`:"";

      if(verification.status==="PASS"){
        return this.result(r,"PASS",`AR A-code ${verification.actual.join(", ")} matches the Event Description. Match confidence: ${verification.matchConfidence}%.${sourceText}`,
          "",{
            current:ar.value,
            eventDescription:ev.value,
            expected,
            suggestion:verification.dataset,
            officialSuggestions:verification.official,
            confidence:verification.matchConfidence,
            verification
          });
      }

      if(verification.status==="REVIEW"){
        return this.result(r,"REVIEW",`AR A-code ${verification.actual.join(", ")} is supported by an alternative IMDRF candidate, but the top candidate is not a complete dual-source match. Review confidence: ${verification.matchConfidence}%.${sourceText}`,
          `Review the top coding-examples and official IMDRF suggestions before accepting AR Code. Suggested candidate: ${expected}.`,{
            current:ar.value,
            eventDescription:ev.value,
            expected,
            suggestion:verification.dataset,
            officialSuggestions:verification.official,
            confidence:verification.matchConfidence,
            verification
          });
      }

      return this.result(r,"FAIL",`AR A-code ${verification.actual.join(", ")} does not match the top IMDRF suggestion ${expected}. Candidate confidence: ${verification.matchConfidence}%.`,
        `Review/correct AR Code to ${expected}, only if supported by the Event Description.`,{
          current:ar.value,
          expected,
          suggestion:verification.dataset,
          officialSuggestions:verification.official,
          confidence:verification.matchConfidence,
          verification
        });
    }

    if(r.id==="CO-044"){
      const h=this.field(t,["Has Health Effect Codes","Complaint: Has Health Effect Codes"]);
      const hp=this.field(t,["Complaint Codes - Patient","Complaint: Complaint Codes - Patient"]);
      const po=this.field(t,["Patient Outcome","Complaint: Patient Outcome"]);
      const at=this.field(t,["Event Occurred At","Complaint: Event Occurred At"]);
      const proc=this.field(t,["Procedure Outcome","Complaint: Procedure Outcome"]);
      if(!h.found)return this.result(r,"REVIEW","Has Health Effect Codes field could not be located.","Verify health-effect coding status.");
      if(["no","false","0"].includes(this.key(h.value)))return this.result(r,"PASS","Health Effect Codes are not indicated.","");
      if(!hp.found||this.empty(hp.value))return this.result(r,"FAIL","Health Effect Codes are indicated but Patient/Health Effect codes are blank.","Populate the applicable Patient/Health Effect code(s).");
      const actualText=String(hp.value ?? ""), expected=[];
      const a=this.key(at.value), p=this.key(po.value), pr=this.key(proc.value);
      const fieldValues={
        "Has Health Effect Codes":h.value,
        "Complaint Codes - Patient":hp.value,
        "Patient Outcome":po.value,
        "Event Occurred At":at.value,
        "Procedure Outcome":proc.value
      };

      // Deterministic health-effect mappings. Use the exact supplied field values
      // after normalization only (case/spacing/punctuation), without inventing
      // alternate business values. NI / No Information / No Information Available
      // are normalized by key() to the same logical value: ni.
      const procedureNoHarm = [
        "noneseriousinjurynoadversepatienteffect", "none", "ni"
      ];
      const nonClinicalEvent = [
        "reprocessing", "serviceormaintenance", "installation",
        "labordemonstration", "outofboxfailure"
      ];
      const setupInspection = "duringsetupinspectionforuseorbeforepatientarrival";
      const askedUnknown = ["askedbutunknown", "ni"];
      const backupOrCompetitor = ["olympusbackupdevice", "competitordevice"];

      if(a==="procedure" && procedureNoHarm.includes(p))
        expected.push("e2403", "f26");

      if(nonClinicalEvent.includes(a) && p==="none")
        expected.push("e2403", "f27");

      if(p==="ni" && askedUnknown.includes(a))
        expected.push("e2401", "f24");

      if(a===setupInspection)
        expected.push("e2403", "f2601");

      if(p==="proceduraldelay" && backupOrCompetitor.includes(pr))
        expected.push("f2301");

      // CO-044 is a mapping comparison. If a supplied mapping is triggered,
      // validate the expected code(s). Never fall back to the old generic
      // "no mapping triggered" REVIEW for an explicitly supported combination.
      if(!expected.length)
        return this.result(
          r,
          "PASS",
          "Health-effect codes are populated; no supported deterministic mapping was triggered.",
          "No correction is proposed because none of the supplied CO-044 mapping conditions apply.",
          {current:hp.value, patientOutcome:po.value, eventOccurredAt:at.value, procedureOutcome:proc.value, fieldValues}
        );
      const unique=[...new Set(expected)];
      const actualCodes = (actualText.match(/(?:^|[^A-Z0-9])([A-F]\d{2,7})(?=[^A-Z0-9]|$)/gi) || []).map(x=>x.match(/[A-F]\d{2,7}/i)?.[0].toLowerCase()).filter(Boolean);
      const missing=unique.filter(x=>!actualCodes.includes(String(x).trim().toLowerCase()));
      return missing.length
        ?this.result(r,"FAIL",`Expected health-effect code(s) are missing: ${missing.join(", ")}.`,"Add the missing code(s) required by the triggered health-effect mapping.",{current:hp.value,expected:unique.join(", "),fieldValues})
        :this.result(r,"PASS",`Health-effect coding matches the triggered mapping: ${unique.join(", ")}.`,"",{current:hp.value,expected:unique.join(", "),fieldValues});
    }

    if(r.id==="CO-001"){
      const s=this.field(t,["Product Summary"]),fam=this.field(t,["Product Family"]),mod=this.field(t,["Model Number"]),item=this.field(t,["Item Code"]);
      if(!s.found||!fam.found||!mod.found||!item.found)return this.result(r,"REVIEW","Product Summary or one of Product Family, Model Number, Item Code could not be verified.","Verify all four product fields.");
      const m=s.value.match(/^\s*([^:]+)\s*:\s*([^|]+)\|\s*([^\s(]+)\s*(?:\((.*?)\))?/);
      if(!m)return this.result(r,"FAIL","Product Summary could not be parsed as Family: Model | ItemCode.","Correct Product Summary format.");
      const ok=this.key(m[1])===this.key(fam.value)&&this.key(m[2])===this.key(mod.value)&&this.key(m[3])===this.key(item.value);
      return ok?this.result(r,"PASS","Product Summary agrees with Product Family, Model Number and Item Code.","")
        :this.result(r,"FAIL","Product Summary does not agree with one or more structured product fields.","Correct Product Summary or the structured product fields.",{current:s.value});
    }

    return null;
  }

  hasAny(text,terms){
    const low=this.norm(text).toLowerCase();
    return terms.some(t=>low.includes(String(t).toLowerCase()));
  }

  codeList(text,letter){
    if(!text)return [];
    const re=new RegExp("\\b"+letter+"\\s*[-:]?\\s*(\\d{2,8})\\b","gi");
    return [...text.matchAll(re)].map(m=>this.canonicalCode(letter+m[1])).filter(Boolean);
  }

  failures(text){
    const lines=String(text||"").split(/\n+/).map(x=>this.norm(x)).filter(Boolean);
    return lines.filter(x=>/\\b(required|confirmed|not confirmed|failure|failed|defect|damage|crack|kink|snag|break|leak|loose|missing|malfunction|recommended)\\b/i.test(x));
  }

  productAnalysisChecks(r){
    const inv=this.text("investigation"), comp=this.text("complaint");
    const low=(inv+"\n"+comp).toLowerCase();

    if(r.id==="INV-024" || /prooduct analysis/i.test(r.field||"")){
      if(!inv)return this.result(r,"REVIEW","Investigation page is not captured.","Capture the Investigation page.");
      const failures=this.failures(inv);
      if(!failures.length)return this.result(r,"REVIEW","No product-analysis failure lines could be identified in the captured Investigation page.","Verify the Product Analysis/QIR section is captured.");
      const required=failures.filter(x=>/\brequired\b/i.test(x));
      const recommended=failures.filter(x=>/\brecommended\b/i.test(x));
      return recommended.length
        ?this.result(r,"REVIEW",
          `Product Analysis content detected: ${failures.length} failure-related line(s), including ${required.length} REQUIRED and ${recommended.length} RECOMMENDED.`,
          `Review RECOMMENDED failures against the Event Description and retain only relevant failures.`,
          {failureCount:failures.length,requiredCount:required.length,recommendedCount:recommended.length})
        :this.result(r,"PASS",
          `Product Analysis content detected: ${failures.length} failure-related line(s), including ${required.length} REQUIRED and no RECOMMENDED failures requiring review.`,
          "",
          {failureCount:failures.length,requiredCount:required.length,recommendedCount:recommended.length});
    }

    if(/as investigated codes/i.test(r.field||"")){
      const a=this.codeList(inv,"A"),g=this.codeList(inv,"G"),c=this.codeList(inv,"C"),d=this.codeList(inv,"D");
      const failures=this.failures(inv);
      if(!failures.length)return this.result(r,"REVIEW","No required failure text was detected for coding.","Capture the Product Analysis/QIR failure section.");
      const missing=[];
      if(!a.length)missing.push("A");
      if(!g.length)missing.push("G");
      if(!c.length)missing.push("C");
      if(!d.length)missing.push("D");
      if(missing.length)return this.result(r,"FAIL",`Required failure coding is incomplete: missing ${missing.join(", ")} code type(s).`,`Every REQUIRED failure should have the applicable A/G/C/D coding before investigation closure.`);
      return this.result(r,"REVIEW",`A/G/C/D coding is present in the captured investigation content.`,`Review each code against the specific failure and official IMDRF terminology before acceptance.`,{A:a,G:g,C:c,D:d});
    }

    if(/ai codes/i.test(r.field||"")){
      const a=this.codeList(inv,"A"),g=this.codeList(inv,"G"),c=this.codeList(inv,"C"),d=this.codeList(inv,"D");
      if(a.length&&g.length&&c.length&&d.length)return this.result(r,"PASS","AI/As Investigated A/G/C/D codes are present.","");
      return this.result(r,"REVIEW","One or more A/G/C/D code types are not visible in the captured Investigation content.","Review the failure-by-failure coding and ensure applicable A/G/C/D terms are populated.",{A:a,G:g,C:c,D:d});
    }

    if(/ar codes/i.test(r.field||"")){
      const a=this.codeList(comp,"A");
      if(a.length)return this.result(r,"PASS","Reported A-code is present in the captured Complaint content.","");
      return this.result(r,"REVIEW","No reported A-code was detected.","Generate/verify the reported A-code from the Event Description using the IMDRF terminology.");
    }

    if(/health effect codes/i.test(r.field||"")){
      const patient=this.field(comp,["Patient Outcome","Patient outcome","Outcome"]);
      const eventAt=this.field(comp,["Event Occurred At","Event Occurred","Event Occurred At?"]);
      if(!patient.found||!eventAt.found)return this.result(r,"REVIEW","Patient Outcome and Event Occurred At could not both be located.","Verify the health-effect coding inputs.");
      return this.result(r,"REVIEW","Health-effect coding inputs are present and require rule-based mapping.","Map Patient Outcome + Event Occurred At to the applicable health-effect codes.",{patientOutcome:patient.value,eventOccurredAt:eventAt.value});
    }

    return null;
  }

  investigationDecisionChecks(r){
    const inv=this.text("investigation"), comp=this.text("complaint");
    const low=this.norm(inv+"\n"+comp).toLowerCase();

    if(/labelling review/i.test(r.field||"")){
      const trigger=this.hasAny(low,["user mishandling","user handling","foreign material","non-olympus","non olympus","pathway 1","pathway1"]);
      const codes=this.codeList(inv,"A");
      const allPTI=codes.length>0 && codes.every(x=>/pti/i.test(x));
      if(allPTI)return this.result(r,"PASS","All detected A-codes are PTI; Labelling Review should be skipped per the workbook.","");
      return trigger
        ?this.result(r,"REVIEW","Labelling Review trigger condition detected.","Perform Labelling Review and verify the applicable IFU statement.")
        :this.result(r,"PASS","No Labelling Review trigger was detected from the captured text.","Apply the standard 'Not required' template if the business rule is satisfied.");
    }

    if(/dhr review/i.test(r.field||"")){
      const trigger=this.hasAny(low,["packaging issue","sterile breach","repair history","pathway = 1","pathway1"]);
      const codes=this.codeList(inv,"A");
      const allPTI=codes.length>0 && codes.every(x=>/pti/i.test(x));
      if(allPTI)return this.result(r,"PASS","All detected A-codes are PTI; DHR/SHR Review should be skipped per the workbook.","");
      return trigger
        ?this.result(r,"REVIEW","DHR/SHR trigger condition detected.","Perform DHR/SHR Review and document the result.")
        :this.result(r,"REVIEW","No DHR/SHR trigger could be conclusively established from captured text.","Verify Pathway and instrument history before applying the standard template.");
    }

    if(/risk review/i.test(r.field||"")){
      const a=this.codeList(inv,"A").filter(x=>!/^pti/i.test(x));
      if(!a.length)return this.result(r,"N/A","No non-PTI A-codes were detected; Risk Review trigger is not present.","");
      return this.result(r,"REVIEW",`Non-PTI A-code(s) detected: ${a.join(", ")}.`,`Run the DnA coding-example complaint check using Model Number + A-code and determine whether a new risk exists.`,{A:a});
    }

    if(/complaint history review/i.test(r.field||"")){
      const a=this.codeList(inv,"A").filter(x=>!/^pti/i.test(x));
      if(!a.length)return this.result(r,"N/A","No non-PTI A-codes were detected; Complaint History Review can be skipped.","");
      return this.result(r,"REVIEW",`Complaint History Review is triggered by non-PTI A-code(s): ${a.join(", ")}.`,`Run trend/UCL review and create an NCR action if UCL is exceeded.`,{A:a});
    }

    if(/capa history review/i.test(r.field||"")){
      const a=this.codeList(inv,"A").filter(x=>!/^pti/i.test(x));
      if(!a.length)return this.result(r,"N/A","No non-PTI A-codes were detected; CAPA History Review can be skipped.","");
      return this.result(r,"REVIEW","CAPA History Review is triggered by non-PTI coding.","Search CAPA history using Model Number and failure keywords; link CAPA# and corrective actions if a match exists.",{A:a});
    }

    if(/escalation determination/i.test(r.field||"")){
      const trigger=this.hasAny(low,["new risk","ncr raised","capa","scar","msa","hha"]);
      return trigger
        ?this.result(r,"REVIEW","Potential escalation trigger detected in the captured case.","Capture escalation type and reference number, if applicable.")
        :this.result(r,"PASS","No explicit escalation trigger was detected in captured text.","");
    }

    if(/investigation summary/i.test(r.field||"")){
      const requiredSections=["product analysis","labelling review","dhr","risk review","complaint history","capa"];
      const present=requiredSections.filter(x=>low.includes(x));
      return present.length>=3
        ?this.result(r,"REVIEW",`Investigation Summary references ${present.length} expected review section(s), but completeness still requires human verification.`,`Verify the final summary also includes complaint confirmation, failure summary and D-code conclusion.`)
        :this.result(r,"REVIEW","Investigation Summary could not be verified as complete from captured text.","Compile Product Analysis, coding, Labelling, DHR/SHR, Risk, CHR, CAPA and Escalation outputs.");
    }

    if(/investigation type codes/i.test(r.field||"")){
      const b=this.codeList(inv,"B");
      if(!b.length)return this.result(r,"REVIEW","No B-code was detected.","Verify B-codes based on the investigation activities performed.");
      return this.result(r,"PASS",`B-code(s) detected: ${b.join(", ")}.`,"Verify they correspond to the actual investigation activities.",{B:b});
    }

    return null;
  }

  codingSections(){
    const text=this.text("coding");
    const lines=String(text||"").split(/\n+/).map(x=>this.norm(x)).filter(Boolean);
    const out=[];
    let current=null;
    const isHeader=x=>/^(failure|failure description|complaint failure|event|problem|issue|failure\s*\d+|#\d+)/i.test(x);
    for(let i=0;i<lines.length;i++){
      const line=lines[i];
      const codes={};
      for(const letter of ["A","G","C","D"]){
        const re=new RegExp("\\b"+letter+"\\s*[:\\-]?\\s*([A-Z]?\\d{2,8})\\b","gi");
        const m=[...line.matchAll(re)];
        if(m.length)codes[letter]=m.map(x=>x[1]);
      }
      if(isHeader(line) || Object.keys(codes).length){
        if(current)out.push(current);
        current={header:line,lines:[line],codes:{}};
        for(const [k,v] of Object.entries(codes))current.codes[k]=v;
      }else if(current){
        current.lines.push(line);
        for(const letter of ["A","G","C","D"]){
          const re=new RegExp("\\b"+letter+"\\s*[:\\-]?\\s*([A-Z]?\\d{2,8})\\b","gi");
          const m=[...line.matchAll(re)].map(x=>x[1]);
          if(m.length)current.codes[letter]=[...(current.codes[letter]||[]),...m];
        }
      }
    }
    if(current)out.push(current);
    return out.filter(x=>Object.keys(x.codes).length);
  }

  codingRecords(){
    return this.codingSections().map(x=>({
      ...x,
      context:x.lines.join(" "),
      codes:Object.fromEntries(Object.entries(x.codes).map(([k,v])=>[k,[...new Set(v)] ]))
    }));
  }

  investigationFailures(){
    const text=this.text("investigation");
    const lines=String(text||"").split(/\n+/).map(x=>this.norm(x)).filter(Boolean);
    const bad=/\b(crack|cracked|break|broken|damage|damaged|degrad|wear|worn|kink|kinking|bent|bend|snag|leak|leaking|block|blocked|obstruct|missing|loose|detached|disconnected|scratch|scratched|tear|torn|split|puncture|hole|malfunction|failure|failed|poor quality|no image|noise|smear|swollen|deteriorat|sticking|resistance|angulation|angulation issue|fray|frayed|corrod|contaminat|misalign|misadjust)\b/i;
    const ignore=/\b(recommend|recommended|if applicable|standard|template|review required)\b/i;
    const candidates=lines.filter(x=>bad.test(x)&&x.length>=5&&!ignore.test(x));

    // Treat wrapped/broken descriptions as one failure.
    const merged=[];
    for(const line of candidates){
      if(!merged.length){merged.push(line);continue;}
      const prev=merged[merged.length-1];
      if(/^(due to|because|and|with|at|on|in|resulting|causing|therefore)\b/i.test(line) || /[:;,]$/.test(prev)){
        merged[merged.length-1]=prev+" "+line;
      }else merged.push(line);
    }
    return [...new Set(merged)].slice(0,100);
  }

  wordSimilarity(a,b){
    const aa=this.norm(a).toLowerCase().split(/\s+/).filter(x=>x.length>2);
    const bb=new Set(this.norm(b).toLowerCase().split(/\s+/).filter(x=>x.length>2));
    if(!aa.length||!bb.size)return 0;
    let hits=0;for(const x of aa)if(bb.has(x))hits++;
    return hits/aa.length;
  }

  parseInvestigation(){
    const text=this.text("investigation");
    const section=(name,nextNames=[])=>{
      const re=new RegExp(name+"\\s*([\\s\\S]*?)(?="+nextNames.map(x=>this.esc(x)).join("|")+"|$)","i");
      const m=text.match(re);
      return m?this.norm(m[1]):"";
    };
    const productAnalysis=section("Product Analysis",["Labeling Review","DHR Review","Risk Review"]);
    const labeling=section("Labeling Review",["DHR Review","Risk Review"]);
    const dhr=section("DHR Review",["Risk Review"]);
    const risk=section("Risk Review",["Complaint / CAPA History Review","Escalation Determination"]);
    const history=section("Complaint / CAPA History Review",["Escalation Determination","Investigation Summary"]);
    const escalation=section("Escalation Determination",["Investigation Summary"]);
    const summary=section("Investigation Summary",["Investigation Summary Local Language","Product Information"]);
    const failures=[];
    const lines=productAnalysis.split(/\n+/).map(x=>this.norm(x)).filter(Boolean);

    for(const line of lines){
      // A numbered Product Analysis failure, including several codes on one line.
      if(/^\d+\.\s*/.test(line)||/\bA\d{2,6}\s*-\s*/i.test(line)){
        const codes={};
        for(const L of ["A","G","C","D"]){
          const re=new RegExp("\\b"+L+"\\s*[:\\-]?\\s*([A-Z]?\\d{2,8})\\s*-?\\s*([^)&]+)?","gi");
          const arr=[...line.matchAll(re)].map(m=>({code:m[1],term:this.norm(m[2]||"").replace(/[,&].*$/,"")}));
          if(arr.length)codes[L]=arr;
        }
        failures.push({text:line,codes});
      }
    }
    return {productAnalysis,labeling,dhr,risk,history,escalation,summary,failures};
  }

  documentationChecks(){
    const inv=this.parseInvestigation();
    const coding=this.codingRecords();
    const comp=this.text("complaint");
    const investigationText=this.text("investigation");
    const out=[];

    const normNarrative=x=>this.norm(x).toLowerCase()
      .replace(/\b\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}\b/g,"")
      .replace(/[^a-z0-9]+/g," ").replace(/\s+/g," ").trim();

    // Complaint Event Description ↔ Investigation Event Description field.
    const cEvent=this.field(comp,["Event Description"]);
    const iEvent=this.field(investigationText,["Event Description"]);
    if(cEvent.found&&iEvent.found){
      const same=normNarrative(cEvent.value)===normNarrative(iEvent.value);
      out.push({
        id:"DOC-EVENT-DESCRIPTION",
        title:"Complaint ↔ Investigation — Event Description",
        phase:"Investigation",
        type:"documentation",
        status:same?"PASS":"FAIL",
        message:same?"Investigation Event Description matches Complaint Event Description.":"Investigation Event Description differs from Complaint Event Description.",
        recommendation:same?"":"Correct/synchronize Investigation Event Description with the Complaint Event Description.",
        current:iEvent.value,expected:cEvent.value,
        ruleLogic:"Investigation Event Description should be verified against Complaint."
      });
    }

    // Product Analysis failures must be carried into Investigation Summary.
    const summary=inv.summary.toLowerCase();
    inv.failures.forEach((f,idx)=>{
      const terms=f.text.toLowerCase().replace(/[(),:]/g," ").split(/\s+/)
        .filter(x=>x.length>=5&&!/^(identified|failure|problem|analysis|device)$/.test(x));
      const important=terms.slice(0,12);
      const hits=important.filter(t=>summary.includes(t)).length;
      const threshold=Math.max(2,Math.ceil(important.length*.35));
      out.push({
        id:`DOC-FAILURE-SUMMARY-${idx+1}`,
        title:`Failure ${idx+1} — Product Analysis ↔ Investigation Summary`,
        phase:"Investigation",
        type:"documentation",
        status:hits>=threshold?"PASS":"FAIL",
        message:hits>=threshold
          ?"The Product Analysis failure is represented in the Investigation Summary."
          :"The Product Analysis failure is not sufficiently represented in the Investigation Summary.",
        recommendation:hits>=threshold?"":"Add the complete confirmed failure, associated component and applicable coding to the Investigation Summary.",
        ruleLogic:"All confirmed Product Analysis failures must be reflected in Investigation Summary."
      });
    });

    // Complaint Event Description ↔ Complaint: Investigation Summary.
    const complaintSummary=this.field(comp,["Complaint: Investigation Summary","Investigation Summary"]);
    if(cEvent.found&&complaintSummary.found){
      const et=normNarrative(cEvent.value).split(/\s+/).filter(x=>x.length>4);
      const st=normNarrative(complaintSummary.value);
      const hits=et.filter(t=>st.includes(t)).length;
      const ratio=et.length?hits/et.length:0;
      out.push({
        id:"DOC-EVENT-SUMMARY",
        title:"Event Description ↔ Complaint: Investigation Summary",
        phase:"Investigation",type:"documentation",
        status:ratio>=0.55?"PASS":"FAIL",
        message:ratio>=0.55?"Event Description is represented in Complaint: Investigation Summary.":"Event Description is not sufficiently represented in Complaint: Investigation Summary.",
        recommendation:ratio>=0.55?"":"Add/correct the Event Description in Complaint: Investigation Summary.",
        current:complaintSummary.value,expected:cEvent.value,
        ruleLogic:"Compare Event Description with Complaint: Investigation Summary and verify the event is present."
      });
    }

    // PTI linkage is determined per As Investigated coding record.
    const allCoding=coding.filter(x=>Object.keys(x.codes||{}).length);
    const ptiPattern=/PTI/i;
    const ptiRecords=allCoding.filter(r=>/pti/i.test(r.context||""));
    const nonPtiRecords=allCoding.filter(r=>!/pti/i.test(r.context||""));
    const allPti=allCoding.length>0 && nonPtiRecords.length===0;

    const sectionEvidence=(section,terms)=>this.hasAny(section,terms);
    const checks=[
      ["DOC-LABEL","Labelling Review documentation",inv.labeling,
        ["labeling review","labelling review","no anomalies","if ufi","ifu","device used in accordance","does not require"]],
      ["DOC-RISK","Risk Review documentation",inv.risk,
        ["risk review","historical complaint","unanticipated","new risk","no unanticipated"]],
      ["DOC-CHR","Complaint History Review documentation",inv.history,
        ["complaint history review","complaint rate","ucl","trends","no trends"]],
      ["DOC-CAPA","CAPA History Review documentation",inv.history,
        ["capa history review","no related capas","no capa","capa found"]]
    ];

    // Labeling is required when any non-PTI failure triggers it; if all codes are full PTI, skip is acceptable.
    const labelRequired=!allPti && (
      this.hasAny(inv.productAnalysis,["non-olympus","foreign material","user mishandling","third party","3rd party"]) ||
      /pathway\s*1/i.test(this.field(comp,["Investigation Classification"]).value||"")
    );
    const labelText=inv.labeling;
    out.push({
      id:"DOC-LABELLING",
      title:"Labelling Review documentation",
      phase:"Investigation",type:"documentation",
      status:labelRequired
        ?(labelText&&labelText.length>80?"PASS":"FAIL")
        :(allPti?"PASS":"REVIEW"),
      message:labelRequired
        ?(labelText?"Labelling Review is documented.":"Labelling Review is required but no adequate documentation was found.")
        :(allPti?"All coding records are PTI-linked; Labelling Review may be skipped per the rule.":"Labelling Review requirement needs manual confirmation."),
      recommendation:labelRequired&&!labelText?"Perform and document Labelling Review, including IFU/use assessment and conclusion.":"",
      ruleLogic:"Perform Labelling Review for user mishandling, foreign/non-Olympus component or Pathway 1 unless all codes are full PTI."
    });

    // DHR/SHR documentation requires manual confirmation; do not infer PASS/FAIL from text.
    out.push({
      id:"DOC-DHR",
      title:"DHR/SHR Review documentation",
      phase:"Investigation",type:"documentation",
      status:"REVIEW",
      message:"DHR/SHR requirement needs manual confirmation.",
      recommendation:"Manually confirm whether DHR/SHR is required and document the review/decision as applicable.",
      ruleLogic:"DHR/SHR requirement needs manual confirmation; automated text evidence must not determine PASS/FAIL."
    });

    // Product Analysis failure-level PTI linkage and consolidated non-PTI review traceability.
    // Every failure is evaluated independently and rendered as one table row.
    const failureRecords=this.extractFailureRecords(inv.productAnalysis);
    const riskText=inv.risk||"";
    const historyText=inv.history||"";
    const reviewMatch=(failure,section)=>{
      const nt=this.normNarrative(failure).split(/\s+/).filter(x=>x.length>=5);
      const stop=new Set(["because","water","tightness","lost","device","section","has","have","with","due","from","that","this"]);
      const important=[...new Set(nt.filter(x=>!stop.has(x)))].slice(0,14);
      if(!important.length)return false;
      const st=this.normNarrative(section);
      const hits=important.filter(t=>st.includes(t)).length;
      return hits>=Math.max(2,Math.ceil(important.length*.30));
    };
    const reviewRows=failureRecords.map((f,idx)=>{
      const pti=f.ptiLinked;
      const risk=pti?"N/A":(reviewMatch(f.text,riskText)?"PASS":"FAIL");
      const chr=pti?"N/A":(reviewMatch(f.text,historyText)?"PASS":"FAIL");
      const capa=pti?"N/A":(reviewMatch(f.text,historyText)?"PASS":"FAIL");
      return {
        failureNumber:idx+1,
        failure:f.text,
        pti:pti?f.ptiLinks.join(", "):"No PTI linkage",
        risk,chr,capa,
        ptiLinked:pti,
        recommendation:pti?"":[risk==="FAIL"?"Risk Review":"",chr==="FAIL"?"Complaint History Review":"",capa==="FAIL"?"CAPA History Review":""].filter(Boolean).join("; ")
      };
    });
    if(reviewRows.length){
      const nonPti=reviewRows.filter(x=>!x.ptiLinked);
      const hasFail=nonPti.some(x=>x.risk==="FAIL"||x.chr==="FAIL"||x.capa==="FAIL");
      const hasReview=false;
      const status=hasFail?"FAIL":(nonPti.length?"PASS":"N/A");
      out.push({
        id:"DOC-NONPTI-REVIEW",
        title:"Non-PTI → Review Traceability",
        phase:"Investigation",type:"documentation",status,
        message:status==="FAIL"
          ?`${nonPti.filter(x=>x.risk==="FAIL").length + nonPti.filter(x=>x.chr==="FAIL").length + nonPti.filter(x=>x.capa==="FAIL").length} non-PTI review requirement(s) are not sufficiently traceable.`
          :status==="PASS"?`All ${nonPti.length} non-PTI failure(s) are traceable across the required reviews.`:`All ${reviewRows.length} Product Analysis failure(s) are PTI-linked; non-PTI reviews are not applicable.`,
        recommendation:hasFail?"Review the failed cells and document each non-PTI failure in the applicable review.":"",
        ruleLogic:"For every Product Analysis failure, detect PTI linkage. PTI-linked failures are N/A. Every failure without PTI linkage is checked independently against the applicable review. Risk Review: failure must be represented in Risk Review. Complaint History Review: failure must be represented in Complaint / CAPA History Review. CAPA History Review: failure must be represented in Complaint / CAPA History Review.",
        fieldsReferenced:["Product Analysis","Risk Review","Complaint / CAPA History Review"],
        failureRows:reviewRows
      });
    }

    // Escalation must be documented and consistent with RR/CHR/CAPA.
    const escalationOK=inv.escalation.length>80 && /escalation|ncr|scar|capa|msa|hha|no further escalation/i.test(inv.escalation);
    const escalationTrigger=this.hasAny(inv.risk,["new risk","unanticipated"])||
      this.hasAny(inv.history,["ucl exceeded","capa found","open capa"])||
      this.hasAny(inv.productAnalysis,["ncr","scar","msa","hha","capa"]);
    out.push({
      id:"DOC-ESCALATION",
      title:"Escalation Determination documentation",
      phase:"Investigation",type:"documentation",
      status:escalationOK?(escalationTrigger?"REVIEW":"PASS"):"FAIL",
      message:escalationOK
        ?(escalationTrigger?"Potential escalation trigger exists; Escalation Determination is documented and requires consistency review.":"Escalation Determination is documented and no trigger was detected.")
        :"Escalation Determination is missing or insufficient.",
      recommendation:escalationOK?(escalationTrigger?"Verify Escalation Determination against Risk Review, Complaint History and CAPA results.":""):"Document Escalation Determination based on RR, CHR and CAPA results.",
      ruleLogic:"Escalation Determination must use Risk Review, Complaint History Review and CAPA results."
    });

    return out;
  }

  traceabilityChecks(){
    const inv=this.parseInvestigation();
    const coding=this.codingRecords();
    const complaint=this.text("complaint");
    const out=[];

    // Product identity: Complaint ↔ Investigation.
    const pairs=[
      ["Product",["Product","Product Name"]],
      ["Model Number",["Product Model Number","Model Number"]],
      ["Lot / Serial Number",["Product Lot / Serial Number","Product Lot/Serial Number"]]
    ];
    for(const [label,aliases] of pairs){
      const c=this.field(complaint,aliases), i=this.field(this.text("investigation"),aliases);
      if(c.found&&i.found){
        out.push({
          id:"TRACE-"+label.replace(/\W+/g,"-").toUpperCase(),
          title:`Complaint ↔ Investigation — ${label}`,
          phase:"Traceability",type:"trace",
          status:this.key(c.value)===this.key(i.value)?"PASS":"FAIL",
          message:this.key(c.value)===this.key(i.value)?`${label} matches.`:`${label} does not match.`,
          recommendation:this.key(c.value)===this.key(i.value)?"":`Correct Investigation ${label} to ${c.value}.`,
          ruleLogic:"Complaint and Investigation product identity must remain consistent.",
          current:i.value,expected:c.value
        });
      }
    }

    // Check Investigation Summary repeats the Product Analysis failures.
    inv.failures.forEach((f,i)=>{
      const normalized=f.text.toLowerCase().replace(/[^a-z0-9]+/g," ");
      const terms=normalized.split(/\s+/).filter(x=>x.length>5).slice(0,8);
      const hits=terms.filter(t=>inv.summary.toLowerCase().includes(t)).length;
      if(terms.length>=2){
        out.push({
          id:`TRACE-SUMMARY-${i+1}`,
          title:"Product Analysis ↔ Investigation Summary",
          phase:"Traceability",type:"trace",
          status:hits>=Math.min(3,terms.length)?"PASS":"REVIEW",
          message:hits>=Math.min(3,terms.length)
            ?"Product Analysis failure is represented in Investigation Summary."
            :"Product Analysis failure may be missing or materially changed in Investigation Summary.",
          recommendation:hits>=Math.min(3,terms.length)?"":"Verify the Investigation Summary includes this confirmed failure.",
          ruleLogic:"Investigation Summary should accurately carry forward confirmed Product Analysis failures."
        });
      }
    });

    return {inv,coding,out};
  }

  semanticAccuracy(){
    const failures=this.investigationFailures();
    const coding=this.codingRecords();
    if(!failures.length||!coding.length)return {available:false,failures,coding,items:[]};

    const predictor=this.getPredictor();

    const items=[];
    for(const failure of failures){
      const candidates=predictor?{
        A:predictor.predict(failure,"A",5),
        G:predictor.predict(failure,"G",5),
        C:predictor.predict(failure,"C",5),
        D:predictor.predict(failure,"D",5)
      }:{A:[],G:[],C:[],D:[]};

      // Match to the most semantically similar coding section, not the entire Coding page.
      let best=null,bestScore=0;
      for(const rec of coding){
        const direct=this.wordSimilarity(failure,rec.context);
        const reverse=this.wordSimilarity(rec.context,failure);
        const phrase=this.norm(rec.context).toLowerCase().includes(this.norm(failure).toLowerCase())?0.35:0;
        const score=Math.min(1,direct*.55+reverse*.25+phrase);
        if(score>bestScore){bestScore=score;best=rec;}
      }

      const actual=best?.codes||{};
      const checks={};
      for(const letter of ["A","G","C","D"]){
        const actualCodes=actual[letter]||[];
        const predicted=candidates[letter]||[];
        const top=predicted[0];
        const topMatch=!!(top&&actualCodes.some(code=>this.key(code)===this.key(top.code)));
        const closeMatch=predicted.some(p=>actualCodes.some(code=>this.key(code)===this.key(p.code)));

        // Missing code is a distinct quality failure, not just a low confidence prediction.
        let status="REVIEW";
        if(actualCodes.length && topMatch)status="PASS";
        else if(actualCodes.length && closeMatch)status="REVIEW";
        else if(actualCodes.length && top && !closeMatch)status="FAIL";
        else if(!actualCodes.length && top)status="FAIL";

        checks[letter]={actual:actualCodes,predicted:predicted.slice(0,3),topMatch,closeMatch,status};
      }

      // Applicability: A/G are normally expected for a concrete failure; C/D are expected
      // when investigation has reached a finding/conclusion. We do not invent codes if the
      // failure text does not provide enough evidence.
      const applicable=[];
      if(/\b(crack|break|damage|wear|kink|snag|leak|blocked|missing|loose|detached|scratch|tear|puncture|malfunction|failure|failed|angulation)\b/i.test(failure))applicable.push("A","G");
      if(/\b(found|identified|confirmed|observed|investigation|due to|caused by)\b/i.test(failure))applicable.push("C");
      if(/\b(due to|caused by|root cause|confirmed|traced to)\b/i.test(failure))applicable.push("D");

      const considered=[...new Set(applicable)];
      const failedTypes=considered.filter(x=>checks[x].status==="FAIL");
      const reviewTypes=considered.filter(x=>checks[x].status==="REVIEW");
      const passTypes=considered.filter(x=>checks[x].status==="PASS");

      let verdict="REVIEW";
      if(considered.length && failedTypes.length===0 && reviewTypes.length===0)verdict="PASS";
      else if(failedTypes.length>=1)verdict="FAIL";

      const confidence=Math.round(
        bestScore*35+
        (considered.length?passTypes.length/considered.length:0)*45+
        (considered.length?reviewTypes.length/considered.length:0)*10+
        (considered.length?failedTypes.length===0?10:0:0)
      );

      items.push({
        failure,
        matchedCodingHeader:best?.header||"",
        context:best?.context||"",
        actual,
        checks,
        applicable:considered,
        codingMatchScore:Math.round(bestScore*100),
        confidence:Math.min(99,Math.max(1,confidence)),
        verdict
      });
    }
    return {available:true,failures,coding,items};
  }

  evaluateWorkflow(r){
    const logic=this.norm(r.logic), low=logic.toLowerCase(), page=this.pageFor(r);
    if(!logic)return this.result(r,"N/A","No rule logic provided.","");

    const specialPA=this.productAnalysisChecks(r);
    if(specialPA)return specialPA;
    const specialInv=this.investigationDecisionChecks(r);
    if(specialInv)return specialInv;
    if(/^(open|enter|click|navigate|go to|login|log in|search the|access the)/i.test(low))
      return this.result(r,"N/A","Procedural/navigation instruction.","");

    // Explicit complaint ↔ investigation synchronization rules.
    const fieldName=this.norm(r.field);
    const crossMap={
      "investigation classification":"Investigation Classification",
      "event description":"Event Description",
      "product":"Product",
      "product lot/serial number":"Product Lot/Serial Number",
      "product model number":"Model Number",
      "manufacturing date":"Manufacturing Date",
      "product return expected":"Product Return Expected",
      "product return date":"Product Returned Date",
      "assigned to group":"Assigned to Group",
      "regional complaint handling center":"Regional Complaint Handling Center"
    };

    if(page==="investigation" && /cross verify with complaint|verify with the complaint|auto-sync from complaint|same as complaint|cross verify/i.test(low)){
      const n=crossMap[fieldName.toLowerCase()]||fieldName;
      const aliases=[n,fieldName];
      return this.comparePages(r,aliases,"complaint","investigation",fieldName||n);
    }

    // Complaint Closure values that are explicitly fetched from Investigation.
    if(page==="complaint" && /fetch it from the investigation phase|from investigation phase/i.test(low)){
      const n=fieldName||"Investigation Summary";
      const inv=this.field(this.text("investigation"),[n]);
      const clo=this.field(this.text("complaint"),[n]);
      if(!inv.found||!clo.found)return this.result(r,"REVIEW",`${n} could not be verified on both Investigation and Complaint Closure pages.`,`Verify ${n} is copied from Investigation to Complaint Closure.`);
      return this.key(inv.value)===this.key(clo.value)?this.result(r,"PASS",`${n} matches Investigation Phase.`,""):this.result(r,"FAIL",`${n} does not match Investigation Phase.`,`Copy the Investigation ${n} into Complaint Closure.`,{current:clo.value,expected:inv.value});
    }

    // Generic required field rules.
    if(/blank|not be blank|required|mandatory|must be populated|should be populated|cannot be blank|not empty/i.test(low)){
      const f=this.field(this.text(page||"complaint"),this.names(r.field)||[r.field]);
      if(!f.found)return this.result(r,"REVIEW",`Could not locate ${r.field||"the required field"} in the captured page.`,`Verify and populate ${r.field||"the field"}.`);
      return this.empty(f.value)?this.result(r,"FAIL",`${f.label||r.field} is blank.`,`Populate ${f.label||r.field}.`):this.result(r,"PASS",`${f.label||r.field} is populated.`,"",{current:f.value});
    }

    // Conditional expected values from automation logic.
    const auto=this.norm(r.automationLogic);
    if(/IF\s+/i.test(auto)&&/→|->|then|else/i.test(auto)){
      const f=this.field(this.text(page||"investigation"),this.names(r.field)||[r.field]);
      if(f.found&&!this.empty(f.value)){
        // Simple "Set X = Y" validation.
        const set=auto.match(/set\s*=\s*([A-Za-z0-9 _\-]+)/i);
        if(set&&/if/i.test(auto)&&/→|->/.test(auto)){
          const expected=this.norm(set[1]);
          if(expected&&this.key(f.value)!==this.key(expected)){
            return this.result(r,"FAIL",`${f.label||r.field} does not match the rule's expected value.`,`Update ${f.label||r.field} to ${expected}, if the stated condition is met.`,{current:f.value,expected});
          }
        }
      }
    }

    // If a rule references another field but is not safely evaluable, show REVIEW with its exact automation guidance.
    if(r.fieldsToRefer||r.dependentField||r.automationLogic||/verify|cross|same as|match|consistency|copy|fetch|based on/i.test(low)){
      return this.result(r,"REVIEW","This rule requires contextual or dependency-based validation.",r.automationLogic||r.description||r.logic);
    }

    if(/verify|review|ensure|confirm|check/i.test(low))
      return this.result(r,"REVIEW","Manual/contextual verification is required.",r.automationLogic||r.description||r.logic);

    return this.result(r,"REVIEW","Rule is loaded but not safely automatable from captured text alone.",r.automationLogic||r.description||r.logic);
  }

  run(c){
    this.caseData=c||{pages:{}};
    const out=this.rules.map(r=>{
      if(r.type==="CO")return this.evaluateCO(r)||this.result(r,"REVIEW","CO rule loaded but requires additional field mapping.",r.description||r.logic);
      return this.evaluateWorkflow(r);
    });
    const docs=this.documentationChecks();
    out.push(...docs);
    const trace=this.traceabilityChecks();
    out.push(...trace.out);
    return out;
  }
}
window.QualityEngine=QualityEngine;