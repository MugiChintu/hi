
function frequencyWeightedCodingEvidence(record) {
  const n = Math.max(1, Number(record?._frequency || 1));
  return Math.min(3, 1 + (n - 1) * 0.15);
}
(() => {
  if (globalThis.__QUALITY_COMPANION_CONTENT_LOADED__) return;
  globalThis.__QUALITY_COMPANION_CONTENT_LOADED__ = true;

  let selecting=false,lastHover=null,oldOutline="";

  const clean=s=>String(s||"").replace(/\u00a0/g," ").replace(/[ \t]+/g," ").trim();
  const blockTags=new Set(["P","LI","TR","TD","TH","DIV","SECTION","ARTICLE","DD","DT","H1","H2","H3","H4","H5","H6","LABEL","PRE"]);

  function clear(){
    if(lastHover)lastHover.style.outline=oldOutline;
    lastHover=null;
  }

  function stop(){
    selecting=false;
    clear();
    document.documentElement.style.cursor="";
    window.removeEventListener("mousemove",move,true);
    window.removeEventListener("click",click,true);
    window.removeEventListener("keydown",key,true);
  }

  function bestBlock(el){
    let n=el,b=el;
    while(n&&n!==document.body&&n!==document.documentElement){
      const t=clean(n.innerText||n.textContent);
      if(blockTags.has(n.tagName)&&t&&t.length<=3000)b=n;
      n=n.parentElement;
    }
    return b;
  }

  function extract(el){
    const block=bestBlock(el);
    const raw=(block.innerText||block.textContent||"").split(/\n+/).map(clean).filter(Boolean);
    const lines=raw.filter(x=>x.length>=3&&x.length<=500);

    if(lines.length>=2&&lines.length<=100)
      return {text:lines.join("\n"),lines,mode:"multi-line"};

    const one=clean(block.innerText||block.textContent);
    return {text:one.slice(0,3000),lines:[one.slice(0,3000)],mode:"line"};
  }

  function move(e){
    if(!(e.target instanceof Element))return;
    clear();
    lastHover=e.target;
    oldOutline=lastHover.style.outline;
    lastHover.style.outline="3px solid #2563eb";
  }

  function click(e){
    e.preventDefault();
    e.stopPropagation();

    const el=e.target instanceof Element?e.target:null;
    if(!el)return;

    const x=extract(el);
    stop();

    chrome.runtime.sendMessage({
      type:"SECTION_SELECTED",
      payload:{
        text:x.text,
        lines:x.lines,
        title:document.title,
        url:location.href,
        tag:el.tagName,
        mode:x.mode
      }
    }).catch(()=>{});
  }

  function key(e){
    if(e.key==="Escape")stop();
  }

  function start(){
    if(selecting)return;
    selecting=true;
    document.documentElement.style.cursor="crosshair";
    window.addEventListener("mousemove",move,true);
    window.addEventListener("click",click,true);
    window.addEventListener("keydown",key,true);
  }

  chrome.runtime.onMessage.addListener((m,s,r)=>{
    if(m?.type==="PING"){
      r({ok:true});
      return true;
    }

    if(m?.type==="START_SECTION_SELECTION"){
      start();
      r({ok:true});
      return true;
    }

    if(m?.type==="GET_PAGE_TEXT"){
      r({
        text:document.body?.innerText?.slice(0,100000)||"",
        lines:(document.body?.innerText||"").split(/\n+/).map(clean).filter(Boolean),
        title:document.title,
        url:location.href,
        mode:"page"
      });
      return true;
    }

    return true;
  });
})();