
function frequencyWeightedCodingEvidence(record) {
  const n = Math.max(1, Number(record?._frequency || 1));
  return Math.min(3, 1 + (n - 1) * 0.15);
}
chrome.runtime.onInstalled.addListener(() => {
  if (chrome.sidePanel?.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  }
});