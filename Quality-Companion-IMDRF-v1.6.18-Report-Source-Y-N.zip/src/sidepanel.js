
function frequencyWeightedCodingEvidence(record) {
  const n = Math.max(1, Number(record?._frequency || 1));
  return Math.min(3, 1 + (n - 1) * 0.15);
}
const $=id=>document.getElementById(id);
const KEY="quality_excel_results";
let workbookRows=[];
let complaintCases=[];
let currentResults=[];
let currentFilter="ALL";
let rules=[];
let imdrfStore=null;
let imdrfInitPromise=null;

function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function setStatus(t,k="idle"){
  const el=$("fileMeta");
  if(el){el.textContent=t;el.className=`status ${k}`;}
  const m=String(t).match(/(?:…|:)\s*(\d+)%/);
  const pct=m?Math.max(0,Math.min(100,Number(m[1]))):null;
  const track=$("excelProgress");
  const fill=$("excelProgressFill");
  if(track&&fill){
    if(k==="working" && pct!==null){track.hidden=false;fill.style.width=`${pct}%`;track.setAttribute("aria-valuenow",String(pct));}
    else if(k==="success"){track.hidden=false;fill.style.width="100%";track.setAttribute("aria-valuenow","100");}
    else if(k==="error"||k==="idle"){track.hidden=true;fill.style.width="0%";track.setAttribute("aria-valuenow","0");}
  }
}

function norm(v){return String(v??"").replace(/\u00a0/g," ").replace(/\s+/g," ").trim();}
function value(row, names){
  for(const n of names){
    if(Object.prototype.hasOwnProperty.call(row,n) && norm(row[n])!=="")return row[n];
  }
  return "";
}
function canonicalMap(row){
  const m={};
  Object.entries(row).forEach(([k,v])=>{
    m[k]=v;
    m[k.replace(/^Complaint:\s*/i,"")]=v;
  });
  // Practical aliases used by workbook rules.
  const aliases={
    "Product Summary":"Complaint: Product Summary",
    "Product Family":"Complaint: Product Family",
    "Model Number":"Complaint: Model Number",
    "Item Code":"Complaint: Item Code",
    "Report Source":"Complaint: Report Source",
    "Report Source (Other)":"Complaint: Report Source (Other)",
    "Communication Channel":"Complaint: Communication Channel",
    "Language":"Complaint: Language",
    "Country of Occurrence":"Complaint: Country of Occurrence",
    "Date of Event":"Complaint: Date of Event",
    "Date of Event Unknown":"Complaint: Date of Event Unknown",
    "Reporter Phone":"Complaint: Reporter Phone",
    "Reporter Email":"Complaint: Reporter Email",
    "Reporter Occupation":"Complaint: Reporter Occupation",
    "Customer Name":"Complaint: Customer Name",
    "Customer Address":"Complaint: Customer Address",
    "Due Diligence Contact Occupation":"Complaint: Due Diligence Contact Occupation",
    "Manufacture Date":"Complaint: Manufacture Date",
    "Product Lot/Serial Number Unknown":"Complaint: Product Lot/Serial Number Unknown",
    "Product Lot / Serial Number":"Product Lot / Serial Number",
    "Usage of Device":"Complaint: Usage of Device",
    "Qty Affected":"Complaint: Qty Affected",
    "Is this a recycled single-use device?":"Complaint: Is this a recycled single-use device?",
    "Culture Test Positive":"Complaint: Culture Test Positive",
    "Device Operator":"Complaint: Device Operator",
    "Procedure Name":"Complaint: Procedure Name",
    "Procedure Outcome":"Complaint: Procedure Outcome",
    "Procedure Type":"Complaint: Procedure Type",
    "Patient Outcome":"Complaint: Patient Outcome",
    "When during Procedure did event occur?":"Complaint: When during Procedure did event occur?",
    "Event Occurred At":"Complaint: Event Occurred At",
    "Asset Flag":"Complaint: Asset Flag",
    "Other Devices Involved":"Complaint: Were other devices involved in event?",
    "Device Available for Evaluation":"Complaint: Device available for evaluation?",
    "Product Return Status":"Complaint: Product Return Status",
    "Death":"Complaint: Was there a Death?",
    "Procedure Prolonged":"Complaint: Was the procedure prolonged...",
    "Patient Infection":"Complaint: Any (suspected) patient infection?",
    "AI Codes":"Complaint: AI Codes",
    "AR Codes":"Complaint: AR Codes",
    "Has Health Effect Codes":"Complaint: Has Health Effect Codes"
  };
  for(const [alias,src] of Object.entries(aliases))m[alias]=row[src]??row[alias]??"";
  return m;
}
function rowText(row){
  return Object.entries(row).map(([k,v])=>`${k}: ${norm(v)}`).filter(x=>!/:\\s*$/.test(x)).join("\n");
}
function pageCase(row){
  const fmap=canonicalMap(row);
  const complaintText=rowText(row);
  const invKeys=[
    "Investigation Classification","Event Description","Product Analysis","Labeling Review","DHR Review",
    "Risk Review","Complaint / CAPA History Review","Escalation Determination","Investigation Summary",
    "Product","Product Lot / Serial Number","Product Model Number","Model Number","Complaint: Investigation Summary"
  ];
  const inv={};
  invKeys.forEach(k=>{if(row[k]!==undefined)inv[k]=row[k]});
  const preserve=(v)=>String(v??"").replace(/\\u00a0/g," ").trim();
  const invText=Object.entries(inv).map(([k,v])=>`${k}: ${preserve(v)}`).filter(x=>!/:\\s*$/.test(x)).join("\n");
  const ai=String(value(row,["Complaint: AI Codes","AI Codes","Complaint: Complaint Codes"]));
  const ar=String(value(row,["Complaint: AR Codes","AR Codes"]));
  const codingText=`As Reported Codes: ${ar}\nAs Investigated Codes: ${ai}\n${norm(row["Complaint: Complaint Codes"]||"")}`;
  return {
    id:value(row,["Complaint: Complaint Number","Complaint Number"])||"Complaint",
    pages:{
      complaint:{text:complaintText,lines:complaintText.split("\n"),pageType:"complaint"},
      investigation:{text:invText,lines:invText.split("\n"),pageType:"investigation"},
      coding:{text:codingText,lines:codingText.split("\n"),pageType:"coding"}
    },
    fieldMaps:{complaint:fmap,investigation:canonicalMap(row),coding:fmap}
  };
}

function rowSpecificRules(){
  // CO rules + explicitly requested additional CO verifications.
  return rules.filter(r=>r.type==="CO");
}

function evaluateRow(row){
  const cd=pageCase(row);
  const engine=new QualityEngine(rowSpecificRules(),{imdrfStore});
  return {case:cd,results:engine.run(cd)};
}

function nonPtiTableHtml(r){
  if(r.id!=="DOC-NONPTI-REVIEW" || !Array.isArray(r.failureRows)) return "";
  const badge=(v)=>`<span class="npStatus ${String(v).toLowerCase().replace(/[^a-z]/g,"")}">${esc(v)}</span>`;
  return `<div class="nonPtiPanel">
    <div class="nonPtiTitle"><div><b>Failure-level review traceability</b><span>Product Analysis → Risk / Complaint History / CAPA</span></div><strong>${esc(r.status)}</strong></div>
    <div class="nonPtiTableWrap"><table class="nonPtiTable"><thead><tr><th>Failure</th><th>PTI</th><th>Risk Review</th><th>Complaint History</th><th>CAPA History</th></tr></thead><tbody>
      ${r.failureRows.map(x=>`<tr>
        <td><div class="npFailureNo">Failure ${x.failureNumber}</div><div class="npFailureText">${esc(x.failure)}</div></td>
        <td>${badge(x.ptiLinked ? x.pti : "No PTI")}</td>
        <td>${badge(x.risk)}</td><td>${badge(x.chr)}</td><td>${badge(x.capa)}</td>
      </tr>`).join("")}
    </tbody></table></div>
  </div>`;
}

function codeEvidenceHtml(r){
  if(r.id==="CO-043" && r.verification){
    const v=r.verification, ds=v.dataset||[], off=v.official||[], gd=v.gDataset||[], go=v.gOfficial||[];
    return `<div class="codingEvidence arEvidence">
      <div class="arEvidenceHeader"><div><b>CO-043 • Verify AR Code</b> <span class="pill">${esc(v.status||r.status)}</span></div><span>Match confidence: <b>${esc(v.matchConfidence||r.confidence||0)}%</b></span></div>
      <div class="eventDescriptionBox"><div class="eventDescriptionLabel">Event Description</div><div class="eventDescriptionText">${esc(v.eventDescription||r.eventDescription||value(currentRowForRender||{},["Event Description"])||"Not available")}</div></div>
      <div class="evidenceLine"><b>Actual AR A-code:</b> ${esc((v.actual||[]).join(", ")||"None")}</div>
      <div class="evidenceGrid">
        <div><b>A — Medical Device Problem</b>${ds.slice(0,3).map(x=>`<span>${esc(x.code)} — ${esc(x.label)} <em>${esc(x.confidence)}%</em></span>`).join("")||"<span>No candidate</span>"}</div>
        <div class="arComponentEvidence"><b>G — Medical Device Component</b>${gd.slice(0,3).map(x=>`<span>${esc(x.code)} — ${esc(x.label)} <em>${esc(x.confidence)}%</em></span>`).join("")||"<span>No G candidate</span>"}</div>
      </div>
    </div>`;
  }
  if(r.id==="CO-042" && r.verification){
    const items=r.verification.items||[];
    return `<div class="codingEvidence"><div><b>AI / Product Analysis verification</b> <span>Failure-level coding match</span></div>
      ${items.slice(0,12).map((x,i)=>{
        const m=x.match||{}, a=x.suggestions||{};
        return `<div class="failureEvidence">
          <b>Failure ${i+1}:</b> ${esc(x.failure)}
          <div class="evidenceLine"><b>Actual AI tuple:</b> ${esc(m.actual?["A","G","C","D"].filter(L=>m.actual[L]).map(L=>L+":"+m.actual[L]).join(" | "):"No tuple matched")}</div>
          <div class="evidenceLine"><b>Match:</b> ${esc(m.status||"REVIEW")} • ${esc(m.score||0)}% code match • <b>${esc(m.confidence||0)}% confidence</b></div>
          <div class="suggestedCodes">${["A","G","C","D"].map(L=>a[L]?.[0]?`<span><b>${L}</b> ${esc(a[L][0].code)} — ${esc(a[L][0].label)} <em>${esc(a[L][0].confidence)}%</em></span>`:"").join("")}</div>
        </div>`;
      }).join("")}
      ${items.length>12?`<small>Showing first 12 of ${items.length} detected failures.</small>`:""}
    </div>`;
  }
  return "";
}

const HIDDEN_UI_CHECK_CODES = new Set([
  "DOC-EVENT-DESCRIPTION",
  "DOC-EVENT-SUMMARY",
  "DOC-LABELLING",
  "DOC-DHR",
  "DOC-NONPTI-REVIEW",
  "DOC-ESCALATION",
  "TRACE-PRODUCT",
  "TRACE-MODEL-NUMBER",
  "TRACE-LOT-SERIAL-NUMBER"
]);

function isHiddenUiCheck(r){
  const id=String(r?.id||r?.ruleCode||r?.code||"");
  const title=String(r?.title||"");
  return HIDDEN_UI_CHECK_CODES.has(id) ||
    /^(Complaint ↔ Investigation — Event Description|Event Description ↔ Complaint: Investigation Summary|Labelling Review documentation|DHR\/SHR Review documentation|Non-PTI → Review Traceability|Escalation Determination documentation|Complaint ↔ Investigation — Product|Complaint ↔ Investigation — Model Number|Complaint ↔ Investigation — Lot \/ Serial Number)$/.test(title);
}

function friendlyRuleLogic(r){
  const id=String(r?.id||"");
  const friendly={
    "CO-001":"Check that Product Summary follows Family: Model | Item Code, and that all three values match the Product Family, Model Number and Item Code fields.",
    "CO-002":"Check that Product and Model Number are present and that the Product value contains the Model Number.",
    "CO-003":"Compare Assigned To with Complaint: Assigned To. If either is blank, the check is not applicable; otherwise they must match.",
    "CO-004":"If a customer letter is required, it must be attached and have a sent date. If it is not required, the sent date must remain blank.",
    "CO-005":"Report Source must be entered and must be Health Professional, User Facility or Company Representative.",
    "CO-006":"Communication Channel must be selected from Email, Phone, Website, Post, Fax or Face-to-face.",
    "CO-007":"Language must be populated.",
    "CO-008":"The Date of Event and its Unknown checkbox must agree: use the checkbox when the date is unknown, otherwise enter a date and leave Unknown unchecked.",
    "CO-009":"Country of Occurrence must be populated.",
    "CO-010":"Reporter Phone must be populated.",
    "CO-011":"Reporter Email must be populated.",
    "CO-012":"Reporter Occupation must be populated.",
    "CO-013":"Customer Name must be populated.",
    "CO-014":"Customer Address must be populated.",
    "CO-015":"Due Diligence Contact Occupation must be populated.",
    "CO-016":"For Malfunction, Reportable or Serious Injury events, Manufacture Date is required. For other event types, this check does not apply.",
    "CO-017":"Product Lot/Serial Number must be populated.",
    "CO-018":"Lot/Serial Number and its Unknown checkbox must agree: if the number is unknown, check Unknown; otherwise enter the number and leave Unknown unchecked.",
    "CO-019":"Qty Affected must be a number greater than or equal to 1.",
    "CO-020":"Device Type and Usage of Device determine whether Recycled Single-Use Device should be Yes, No or not applicable.",
    "CO-021":"Culture Test Positive must contain one of the allowed values: Yes, No, No Information, ASKU, Refused or Asked but unknown.",
    "CO-022":"Investigation Classification must be Pathway1 or Pathway2.",
    "CO-023":"When a customer letter is attached and has a sent date, both fields must be populated. If a letter is not required, the sent date must be blank.",
    "CO-024":"If Report Source is Other/Others, Report Source (Other) must be populated. For any other source, the additional field is not required.",
    "CO-025":"Device Operator must be Health Professional or otherwise populated.",
    "CO-026":"Procedure Name must be consistent with Event Occurred At according to the process rules.",
    "CO-027":"Procedure Outcome must be consistent with Event Occurred At according to the process rules.",
    "CO-028":"Procedure Type must be consistent with Event Occurred At according to the process rules.",
    "CO-029":"For Reprocessing, Service, Maintenance, Installation, Out-of-Box Failure, During Set Up or Inspection for Use, Patient Outcome must be None. If Event Occurred At is NI/No Information or Patient Outcome is N/A, the check does not require a Patient Outcome value.",
    "CO-030":"The selected 'When during Procedure did event occur' value must be consistent with Event Occurred At according to the process rules.",
    "CO-031":"Event Occurred At must be populated.",
    "CO-032":"Item Code must match the Item Code in Complaint Product Details.",
    "CO-033":"Product Family must match the Product Family in Complaint Product Details.",
    "CO-034":"For Reportable, Malfunction or Serious Injury events, Manufacture Date must be populated. Otherwise this check does not apply.",
    "CO-035":"If Event Description indicates PM or Asset Return, Asset Flag must be TRUE; otherwise it must be FALSE.",
    "CO-036":"If multiple devices are involved and Procedure Outcome indicates a competitor device, Other Devices Involved must be Yes; otherwise it must be No.",
    "CO-037":"Device Available for Evaluation must be Yes or No, must agree with Product Return Expected, and must be Yes for FSE/ESS cases.",
    "CO-038":"When Product Returned is populated, Product Return Status must be Released.",
    "CO-039":"If Patient Outcome is Death, Was There A Death may be Yes or blank. For all other outcomes, it must not be Yes.",
    "CO-040":"If Patient Outcome is Procedure Delay, a duration must be selected. Otherwise, the duration must follow the Event Occurred At process rules.",
    "CO-041":"If infection is indicated in the complaint, Patient Infection must be Yes. Otherwise, Patient Infection must still be populated.",
    "CO-042":"AI Codes must agree with the Investigation Codes and the A/G/C/D coding assigned to each Product Analysis failure.",
    "CO-043":"The AR A-code must represent the Event Description and be consistent with the IMDRF coding recommendation.",
    "CO-044":"When Health Effect Codes apply, calculate the expected Patient Health Effect codes from Patient Outcome, Event Occurred At and Procedure Outcome, then compare them with Complaint Codes - Patient."
  };
  return friendly[id] || String(r?.ruleLogic||"Rule logic not configured")
    .replace(/\bIF\b/g,"If").replace(/\bTHEN\b/g,"then").replace(/\bELSE IF\b/g,"otherwise, if").replace(/\bELSE\b/g,"otherwise")
    .replace(/IS NOT BLANK/g,"is populated").replace(/IS BLANK/g,"is blank").replace(/NOT IN/g,"is not one of").replace(/ IN /g," is one of ");
}

function codeBlockRuleLogic(r){
  const id=String(r?.id||"");
  const blocks={
    "CO-001":`IF Product Summary cannot be parsed
THEN FAIL
ELSE IF Family, Model Number and Item Code all match the structured fields
THEN PASS
ELSE FAIL`,
    "CO-002":`IF Product or Model Number is blank
THEN FAIL
ELSE IF Product contains Model Number
THEN PASS
ELSE FAIL`,
    "CO-003":`IF Assigned To or Complaint: Assigned To cannot be located
THEN REVIEW
ELSE IF either Assigned To value is blank
THEN N/A
ELSE IF Assigned To = Complaint: Assigned To
THEN PASS
ELSE FAIL`,
    "CO-004":`IF Customer Letter Required = No
THEN IF Customer Letter Sent Date is blank
     THEN PASS
     ELSE FAIL
ELSE IF Customer Letter Required = Yes
THEN IF Customer Letter Attached = Yes AND Customer Letter Sent Date is populated
     THEN PASS
     ELSE FAIL
ELSE REVIEW`,
    "CO-005":`IF Report Source is one of Health Professional, User Facility, Company Representative
THEN PASS
ELSE FAIL`,
    "CO-006":`IF Communication Channel is one of Email, Phone, Website, Post, Fax, Face-to-face
THEN PASS
ELSE FAIL`,
    "CO-007":`IF Language is populated
THEN PASS
ELSE FAIL`,
    "CO-008":`IF Date of Event is blank AND Date of Event Unknown = checked
THEN PASS
ELSE IF Date of Event is populated AND Date of Event Unknown = unchecked
THEN PASS
ELSE FAIL`,
    "CO-009":`IF Country of Occurrence is populated
THEN PASS
ELSE FAIL`,
    "CO-010":`IF Reporter Phone is populated
THEN PASS
ELSE FAIL`,
    "CO-011":`IF Reporter Email is populated
THEN PASS
ELSE FAIL`,
    "CO-012":`IF Reporter Occupation is populated
THEN PASS
ELSE FAIL`,
    "CO-013":`IF Customer Name is populated
THEN PASS
ELSE FAIL`,
    "CO-014":`IF Customer Address is populated
THEN PASS
ELSE FAIL`,
    "CO-015":`IF Due Diligence Contact Occupation is populated
THEN PASS
ELSE FAIL`,
    "CO-016":`IF US MDR Type of Reportable Event is Malfunction, Reportable or Serious Injury
THEN IF Manufacture Date is populated
     THEN PASS
     ELSE FAIL
ELSE N/A`,
    "CO-017":`IF Product Lot/Serial Number is populated
THEN PASS
ELSE FAIL`,
    "CO-018":`IF Product Lot/Serial Number is blank AND Unknown = checked
THEN PASS
ELSE IF Product Lot/Serial Number is populated AND Unknown = unchecked
THEN PASS
ELSE FAIL`,
    "CO-019":`IF Qty Affected is numeric AND Qty Affected >= 1
THEN PASS
ELSE FAIL`,
    "CO-020":`IF Device Type = Reuse
THEN Recycled Single-Use Device = No
ELSE IF Device Type = Single Use AND Usage of Device = Reuse
THEN Recycled Single-Use Device = Yes
ELSE IF Device Type = Single Use AND Usage of Device != Reuse
THEN PASS
ELSE N/A`,
    "CO-021":`IF Culture Test Positive is one of Yes, No, No Information, ASKU, Refused, Asked but unknown
THEN PASS
ELSE FAIL`,
    "CO-022":`IF Investigation Classification = Pathway1 OR Pathway2
THEN PASS
ELSE FAIL`,
    "CO-023":`IF Customer Letter Attached = Yes
THEN IF Customer Letter Sent Date is populated
     THEN PASS
     ELSE FAIL
ELSE IF Customer Letter is not required
THEN IF Customer Letter Sent Date is blank
     THEN PASS
     ELSE FAIL
ELSE REVIEW`,
    "CO-024":`IF Report Source = Other OR Others
THEN IF Report Source (Other) is populated
     THEN PASS
     ELSE FAIL
ELSE N/A`,
    "CO-025":`IF Device Operator = Health Professional
THEN PASS
ELSE IF Device Operator is populated
THEN PASS
ELSE FAIL`,
    "CO-026":`IF Event Occurred At is Reprocessing, Service or Maintenance, Installation, Out-of-Box Failure, During Set Up or Inspection for Use
THEN Procedure Name = N/A
ELSE IF Event Occurred At = Asked but unknown
THEN Procedure Name = NI or Asked but unknown
ELSE IF Event Occurred At = NI / No Information
THEN Procedure Name = NI / No Information
ELSE IF Event Occurred At = Procedure
THEN Procedure Name must be populated with a specific value
ELSE REVIEW`,
    "CO-027":`IF Event Occurred At is Reprocessing, Service or Maintenance, Installation, Out-of-Box Failure, During Set Up or Inspection for Use
THEN Procedure Outcome = N/A
ELSE IF Event Occurred At = Asked but unknown
THEN Procedure Outcome = NI or Asked but unknown
ELSE IF Event Occurred At = NI / No Information
THEN Procedure Outcome = NI / No Information
ELSE IF Event Occurred At = Procedure
THEN Procedure Outcome must be populated with a specific value
ELSE REVIEW`,
    "CO-028":`IF Event Occurred At is Reprocessing, Service or Maintenance, Installation, Out-of-Box Failure, During Set Up or Inspection for Use
THEN Procedure Type = N/A
ELSE IF Event Occurred At = Asked but unknown
THEN Procedure Type = NI or Asked but unknown
ELSE IF Event Occurred At = NI / No Information
THEN Procedure Type = NI / No Information
ELSE IF Event Occurred At = Procedure
THEN Procedure Type must be populated with a specific value
ELSE REVIEW`,
    "CO-029":`IF Event Occurred At = NI / No Information
THEN PASS
ELSE IF Patient Outcome = N/A
THEN PASS
ELSE IF Event Occurred At is Reprocessing, Service or Maintenance, Installation, Out-of-Box Failure, During Set Up or Inspection for Use
THEN Patient Outcome = None
ELSE PASS`,
    "CO-030":`IF Event Occurred At is Reprocessing, Service or Maintenance, Installation, Out-of-Box Failure, During Set Up or Inspection for Use
THEN When during Procedure did event occur? = N/A
ELSE IF Event Occurred At = Asked but unknown
THEN value = NI or Asked but unknown
ELSE IF Event Occurred At = NI / No Information
THEN value = NI / No Information
ELSE IF Event Occurred At = Procedure
THEN value must be populated with a specific value
ELSE REVIEW`,
    "CO-031":`IF Event Occurred At is populated
THEN PASS
ELSE FAIL`,
    "CO-032":`IF Item Code matches Complaint Product Details
THEN PASS
ELSE FAIL`,
    "CO-033":`IF Product Family matches Complaint Product Details
THEN PASS
ELSE FAIL`,
    "CO-034":`IF US MDR Type of Reportable Event = Reportable, Malfunction or Serious Injury
THEN IF Manufacture Date is populated
     THEN PASS
     ELSE FAIL
ELSE N/A`,
    "CO-035":`IF Event Description contains PM OR Asset Return
THEN IF Asset Flag = TRUE / Yes
     THEN PASS
     ELSE FAIL
ELSE IF Asset Flag = FALSE / No
THEN PASS
ELSE FAIL`,
    "CO-036":`IF Event Description indicates multiple devices AND Procedure Outcome indicates a competitor device
THEN IF Other Devices Involved = Yes
     THEN PASS
     ELSE FAIL
ELSE IF Other Devices Involved = No
THEN PASS
ELSE FAIL`,
    "CO-037":`IF Device Available for Evaluation is not Yes or No
THEN FAIL
ELSE IF case is FSE / ESS
THEN IF Device Available for Evaluation = Yes
     THEN PASS
     ELSE FAIL
ELSE IF Product Return Expected = Yes
THEN IF Device Available for Evaluation = Yes
     THEN PASS
     ELSE FAIL
ELSE IF Product Return Expected = No
THEN IF Device Available for Evaluation = No
     THEN PASS
     ELSE FAIL
ELSE PASS`,
    "CO-038":`IF Product Returned Date is populated
THEN IF Product Return Status = Released
     THEN PASS
     ELSE FAIL
ELSE N/A`,
    "CO-039":`IF Patient Outcome = Death
THEN IF Was There A Death = Yes OR blank
     THEN PASS
     ELSE FAIL
ELSE IF Was There A Death != Yes
THEN PASS
ELSE FAIL`,
    "CO-040":`IF Patient Outcome = Procedure Delay
THEN IF Procedure Prolonged is less than 30 minutes OR greater than or equal to 30 minutes
     THEN PASS
     ELSE FAIL
ELSE IF Event Occurred At is Reprocessing, Service or Maintenance, Installation, Out-of-Box Failure, During Set Up or Inspection for Use
THEN Procedure Prolonged = N/A
ELSE IF Event Occurred At = Asked but unknown
THEN Procedure Prolonged = NI or Asked but unknown
ELSE IF Event Occurred At = NI / No Information
THEN Procedure Prolonged = NI / No Information
ELSE IF Event Occurred At = Procedure
THEN Procedure Prolonged must be populated or explicitly unknown as permitted
ELSE REVIEW`,
    "CO-041":`IF Event Description indicates infection, infected, sepsis or contamination
THEN IF Patient Infection = Yes
     THEN PASS
     ELSE FAIL
ELSE IF Patient Infection is populated
THEN PASS
ELSE FAIL`,
    "CO-042":`FOR EACH individual Product Analysis failure
  COMPARE AI A/G/C/D coding with Investigation Codes
  IF complete AI tuple is traceable to applicable Investigation coding
  THEN PASS
  ELSE IF partial or unsupported match exists
  THEN REVIEW`,
    "CO-043":`IF actual AR A-code is supported by both IMDRF Coding Examples and official IMDRF 2026 terminology
THEN PASS
ELSE IF actual AR A-code is supported by either source
THEN REVIEW
ELSE FAIL`,
    "CO-044":`IF Has Health Effect Codes = No / False / 0
THEN PASS
ELSE IF Event Occurred At = Procedure AND Patient Outcome indicates no harm / None / NI
THEN EXPECT E2403 + F26
ELSE IF Event Occurred At is Reprocessing, Service or Maintenance, Installation, Lab or Demonstration or Out-of-Box Failure AND Patient Outcome = None
THEN EXPECT E2403 + F27
ELSE IF Event Occurred At = Asked but unknown OR NI AND Patient Outcome = NI
THEN EXPECT E2401 + F24
ELSE IF Event Occurred At is During Set Up, Inspection for Use or Before Patient Arrival
THEN EXPECT E2403 + F2601
ELSE IF Patient Outcome = Procedure Delay AND Procedure Outcome = Olympus Backup Device OR Competitor Device
THEN EXPECT F2301
ELSE NO CO-044 MAPPING APPLIES

IF any expected Patient Health Effect code is missing
THEN FAIL
ELSE PASS`
  };
  return blocks[id] || `IF ${String(r?.ruleLogic||"Rule condition is met")}
THEN PASS
ELSE FAIL`;
}

function detailedRuleLogic(r){
  const id=String(r?.id||"");
  const details={
    "CO-004":"1) If Customer Letter Required = Yes, Customer Letter Attached must be Yes and Customer Letter Sent Date must be populated. 2) If Customer Letter Required = No, Customer Letter Sent Date must be blank. 3) Any unexpected combination requires review.",
    "CO-008":"1) If Date of Event is blank, Date of Event Unknown must be checked. 2) If Date of Event is populated, Date of Event Unknown must be unchecked. The two fields must always agree.",
    "CO-016":"1) Check US MDR Type of Reportable Event. 2) If the type is Malfunction, Reportable, or Serious Injury, Manufacture Date is required. 3) For other event types, Manufacture Date is not conditionally required.",
    "CO-018":"1) If Product Lot/Serial Number is blank, its Unknown checkbox must be checked. 2) If Product Lot/Serial Number is populated, Unknown must be unchecked.",
    "CO-020":"1) If Device Type = Reuse, Recycled Single-Use Device must be No. 2) If Device Type = Single Use and Usage of Device = Reuse, Recycled Single-Use Device must be Yes. 3) If Device Type = Single Use but Usage of Device is not Reuse, this rule does not define a required Yes/No value. 4) Other Device Type values are outside this rule.",
    "CO-023":"1) If Customer Letter Attached = Yes, Customer Letter Sent Date must be populated. 2) If the letter is not required, Customer Letter Sent Date must be blank. 3) Any other attachment/date combination is inconsistent and requires correction.",
    "CO-024":"1) If Report Source = Other or Others, Report Source (Other) must be populated. 2) For every other Report Source value, Report Source (Other) is not required by this rule.",
    "CO-026":"The Procedure Name must follow the Event Occurred At condition: • Reprocessing, Service, Maintenance, Installation, Out-of-Box Failure, During Set Up, or Inspection for Use → Procedure Name must be N/A. • Asked but unknown → Procedure Name must be NI or Asked but unknown. • NI / No Information → Procedure Name must be NI / No Information. • Procedure → Procedure Name must be populated with a specific value, not NI or Asked but unknown.",
    "CO-027":"The Procedure Outcome must follow the Event Occurred At condition: • Reprocessing, Service, Maintenance, Installation, Out-of-Box Failure, During Set Up, or Inspection for Use → Procedure Outcome must be N/A. • Asked but unknown → Procedure Outcome must be NI or Asked but unknown. • NI / No Information → Procedure Outcome must be NI / No Information. • Procedure → Procedure Outcome must be populated with a specific value, not NI or Asked but unknown.",
    "CO-028":"The Procedure Type must follow the Event Occurred At condition: • Reprocessing, Service, Maintenance, Installation, Out-of-Box Failure, During Set Up, or Inspection for Use → Procedure Type must be N/A. • Asked but unknown → Procedure Type must be NI or Asked but unknown. • NI / No Information → Procedure Type must be NI / No Information. • Procedure → Procedure Type must be populated with a specific value, not NI or Asked but unknown.",
    "CO-029":"1) If Event Occurred At = NI / No Information, the rule passes without forcing Patient Outcome = None. 2) If Patient Outcome = N/A, the rule passes. 3) If Event Occurred At is outside the conditional set, the rule does not apply. 4) If Event Occurred At = Reprocessing, Service, Maintenance, Installation, Out-of-Box Failure, During Set Up, Inspection for Use, or the specified service/maintenance non-clinical condition, Patient Outcome must be None.",
    "CO-030":"The 'When during Procedure did event occur?' value must follow the same Event Occurred At branches: • Reprocessing, Service, Maintenance, Installation, Out-of-Box Failure, During Set Up, or Inspection for Use → N/A. • Asked but unknown → NI or Asked but unknown. • NI / No Information → NI / No Information. • Procedure → a populated specific value, not NI or Asked but unknown.",
    "CO-034":"1) If US MDR Type of Reportable Event = Reportable, Malfunction, or Serious Injury, Manufacture Date is required. 2) For other event types, this conditional requirement does not apply.",
    "CO-035":"1) If Event Description contains PM or Asset Return, Asset Flag must be True/Yes. 2) If neither trigger is present, Asset Flag must be False/No.",
    "CO-036":"1) Detect multiple-device evidence in Event Description (for example, two, multiple, another, competitor, other device, or different device). 2) Also check whether Procedure Outcome indicates a competitor device. 3) If both conditions are present, Other Devices Involved must be Yes. 4) Otherwise it must be No.",
    "CO-037":"1) Device Available for Evaluation must be Yes or No. 2) In FSE/ESS cases it must be Yes. 3) If Product Return Expected = Yes, Device Available for Evaluation must be Yes. 4) If Product Return Expected = No, Device Available for Evaluation must be No.",
    "CO-038":"If Product Returned Date is populated, Product Return Status must be Released. If Product Returned Date is blank, this status requirement does not apply.",
    "CO-039":"1) If Patient Outcome = Death, Was There A Death may be Yes or blank. 2) For every other Patient Outcome, Was There A Death must not be Yes.",
    "CO-040":"1) If Patient Outcome = Procedure Delay, Procedure Prolonged must be either less than 30 minutes or greater than or equal to 30 minutes. 2) If Event Occurred At is Reprocessing, Service, Maintenance, Installation, Out-of-Box Failure, During Set Up, or Inspection for Use, Procedure Prolonged must be N/A. 3) If Event Occurred At = Asked but unknown, Procedure Prolonged must be NI or Asked but unknown. 4) If Event Occurred At = NI / No Information, Procedure Prolonged must be NI / No Information. 5) If Event Occurred At = Procedure, Procedure Prolonged must be populated or explicitly unknown as permitted by the rule.",
    "CO-041":"1) If Event Description indicates infection, infected, sepsis, or contamination, Patient Infection must be Yes. 2) If no infection trigger is found, Patient Infection must still be populated.",
    "CO-042":"1) Identify each individual Product Analysis failure. 2) For each failure, compare the AI A/G/C/D tuple with the corresponding Investigation coding. 3) Every AI tuple must be traceable to an applicable investigation coding record when a complete reference exists. 4) Partial or unsupported matches are flagged for correction or human review. 5) The failure-specific A/G/C/D suggestions are evidence for the review, not an automatic replacement of investigator coding.",
    "CO-043":"1) Read the Event Description as the basis for the As Reported A-code. 2) Compare the actual AR A-code with coding examples and the official IMDRF terminology recommendation. 3) A strong match passes; a supported but non-top/partial match requires review; an unsupported top candidate results in a correction recommendation. 4) The related G component prediction is displayed separately and does not replace the AR A-code check.",
    "CO-044":"1) If Has Health Effect Codes = No/False/0, the rule passes. 2) If health-effect codes are indicated, Complaint Codes - Patient must not be blank. 3) Procedure + Patient Outcome indicating no harm/none/NI → E2403 and F26. 4) Reprocessing/Service or Maintenance/Installation/Lab or Demonstration/Out-of-Box Failure + Patient Outcome = None → E2403 and F27. 5) Asked but unknown or NI with Patient Outcome = NI → E2401 and F24. 6) During Set Up/Inspection for Use/Before Patient Arrival → E2403 and F2601. 7) Patient Outcome = Procedure Delay with Procedure Outcome = Olympus Backup Device or Competitor Device → F2301. 8) Compare the triggered expected codes with the actual Patient/Health Effect codes and flag any missing codes."
  };
  return details[id] || "";
}

function renderComplaintResults(){
  const box=$("complaintResults");
  let list=complaintCases;
  if(currentFilter!=="ALL")list=list.filter(x=>x.results.some(r=>r.status===currentFilter));
  if(!list.length){box.innerHTML=`<div class="empty">No complaints in this filter.</div>`;return;}

  box.innerHTML=list.map((c,i)=>{
    const originalIndex=complaintCases.indexOf(c)+1;
    const visibleResults=c.results.filter(r=>!isHiddenUiCheck(r));
    const fail=visibleResults.filter(r=>r.status==="FAIL").length;
    const review=visibleResults.filter(r=>r.status==="REVIEW").length;
    const pass=visibleResults.filter(r=>r.status==="PASS").length;
    const shown=c.results.filter(r=>!isHiddenUiCheck(r) && (currentFilter==="ALL"||r.status===currentFilter));
    return `<article class="complaintCard ${c.overall.toLowerCase()}">
      <div class="complaintHead">
        <div><span class="rowNo">#${originalIndex}</span><b>${esc(c.case.id)}</b><small>${esc(value(c.row,["Event Description","Complaint: Event Description"]))}</small></div>
        <strong>${c.overall}</strong>
      </div>
      <div class="miniStats"><span>✓ ${pass}</span><span>✕ ${fail}</span><span>⚠ ${review}</span></div>
      <details ${c.overall==="FAIL"?"open":""}><summary>View ${shown.length} checks</summary>
      ${shown.map(r=>`<div class="rowCheck ${String(r.status).toLowerCase()}">
        <div><b>${esc(r.id)} — ${esc(r.title)}</b><small>${esc(r.message)}</small>
        ${nonPtiTableHtml(r)}
        ${r.current!==undefined?`<small>Current: ${esc(r.current||"Blank")}${r.expected!==undefined?` • Expected: ${esc(r.expected)}`:""}</small>`:""}
        ${r.fieldValues?`<div class="fieldValueGrid">${Object.entries(r.fieldValues).map(([k,v])=>`<div><b>${esc(k)}</b><span>${esc(v??"Blank")}</span></div>`).join("")}</div>`:""}
        ${r.recommendation?`<small class="traceRec">${esc(r.recommendation)}</small>`:""}
        ${r.fieldsReferenced?.length?`<small>Fields: ${esc(r.fieldsReferenced.join(" | "))}</small>`:""}
        <details class="ruleTransparency"><summary>Show rule behind this check</summary><div class="ruleLogicPanel">
          <b>Rule ID</b><span>${esc(r.id)}</span>
          <b>Rule logic</b><span>${esc(friendlyRuleLogic(r))}</span>
          ${r.id==="DOC-NONPTI-REVIEW"?`<b>Review checks</b><span class="ruleReviewLines"><i>Risk Review</i> — each non-PTI failure must be traceable in Risk Review.<br><i>Complaint History Review</i> — each non-PTI failure must be traceable in Complaint / CAPA History Review.<br><i>CAPA History Review</i> — each non-PTI failure must be traceable in Complaint / CAPA History Review.</span>`:""}
          <b>Fields referenced</b><span>${esc((r.fieldsReferenced||[]).join(" | ")||"None")}</span>
        </div></details>
        ${r.id!=="CO-043"&&r.suggestions?`<div class="codeSuggestions"><b>IMDRF suggestions</b>${r.suggestions.slice(0,8).map(x=>{
          if(x.failure)return `<div class="failureSuggestion"><small>${esc(x.failure)}</small>${["A","G","C","D"].map(L=>x[L]?.[0]?`<span>${L}: ${esc(x[L][0].code)} — ${esc(x[L][0].label)} <em>${x[L][0].confidence}%</em></span>`:"" ).join("")}</div>`;
          return `<span>${esc(x.code)} — ${esc(x.label)} <em>${x.confidence}%</em></span>`;
        }).join("")}</div>`:""}
        ${codeEvidenceHtml(r)}
      </div>
        <strong>${r.status==="PASS"?"✓":r.status==="FAIL"?"✕":"⚠"}</strong>
      </div>`).join("")}</details>
    </article>`;
  }).join("");
}
function renderTotals(){
  const counts={PASS:0,FAIL:0,REVIEW:0,N_A:0};
  complaintCases.forEach(c=>c.results.forEach(r=>{
    const k=r.status==="N/A"?"N_A":r.status;
    counts[k]=(counts[k]||0)+1;
  }));
  const all=counts.PASS+counts.FAIL+counts.REVIEW+counts.N_A;
  $("allChecks").textContent=all;
  $("pass2").textContent=counts.PASS;
  $("fail").textContent=counts.FAIL;
  $("review").textContent=counts.REVIEW;
  $("rowCount").textContent=`${complaintCases.length} complaint${complaintCases.length===1?"":"s"} • ${all} checks`;
}
function downloadText(filename,text,mime){
  const blob=new Blob([text],{type:mime});
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a");a.href=url;a.download=filename;
  document.body.appendChild(a);a.click();a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function flatReport(){
  const rows=[];
  complaintCases.forEach((c,idx)=>{
    c.results.forEach(r=>{
      rows.push({
        complaintRow:idx+1,
        complaintNumber:c.case.id,
        overall:c.overall,
        ruleId:r.id,
        check:r.title,
        phase:r.phase||"",
        status:r.status,
        current:r.current??"",
        expected:r.expected??"",
        message:r.message||"",
        recommendation:r.recommendation||"",
        fieldsReferenced:(r.fieldsReferenced||[]).join(" | "),
        ruleLogic:codeBlockRuleLogic(r)
      });
    });
  });
  return rows;
}
function csvEscape(v){
  const s=String(v??"");
  return `"${s.replace(/"/g,'""')}"`;
}
function exportJson(){
  if(!complaintCases.length)return;
  const payload={
    product:"Quality Companion",
    version:"1.2",
    exportedAt:new Date().toISOString(),
    ruleCount:rules.filter(r=>r.type==="CO").length,
    complaintCount:complaintCases.length,
    summary:complaintCases.reduce((a,c)=>{
      a[c.overall]=(a[c.overall]||0)+1;return a;
    },{}),
    results:flatReport()
  };
  downloadText("quality-companion-report.json",JSON.stringify(payload,null,2),"application/json");
}
function exportCsv(){
  const rows=flatReport();if(!rows.length)return;
  const headers=Object.keys(rows[0]);
  const csv=[headers.map(csvEscape).join(","),...rows.map(r=>headers.map(h=>csvEscape(r[h])).join(","))].join("\\n");
  downloadText("quality-companion-report.csv",csv,"text/csv;charset=utf-8");
}
function xmlEscape(v){
  return String(v??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");
}
function excelCol(n){let s="";while(n>0){const r=(n-1)%26;s=String.fromCharCode(65+r)+s;n=Math.floor((n-1)/26);}return s;}
async function exportExcel(){
  const rows=flatReport();if(!rows.length)return;
  const headers=Object.keys(rows[0]);
  const all=[headers,...rows.map(r=>headers.map(h=>r[h]))];
  const sheetRows=all.map((row,ri)=>`<row r="${ri+1}" ht="${ri===0?24:(row.some((v,ci)=>headers[ci]==="ruleLogic" )?54:18)}" customHeight="1">${row.map((v,ci)=>{const h=headers[ci]||"";const wrap=(h==="ruleLogic");const style=ri===0?1:(h==="ruleLogic"?3:(wrap?2:0));return `<c r="${excelCol(ci+1)}${ri+1}" s="${style}" t="inlineStr"><is><t>${xmlEscape(v)}</t></is></c>`}).join("")}</row>`).join("");
  const last=`${excelCol(headers.length)}${all.length}`;
  const types=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>`;
  const rootRels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
  const wb=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Quality Report" sheetId="1" r:id="rId1"/></sheets></workbook>`;
  const wbRels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`;
  const styles=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="3"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font><font><sz val="10"/><name val="Consolas"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="solid"><fgColor rgb="D9EAF7"/></patternFill></fill></fills><borders count="1"><border/></borders><cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/><xf numFmtId="0" fontId="1" fillId="1" borderId="0" applyFont="1" applyFill="1"/><xf numFmtId="0" fontId="0" fillId="0" borderId="0" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf><xf numFmtId="0" fontId="2" fillId="0" borderId="0" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf></cellXfs></styleSheet>`;
  const sheet=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><dimension ref="A1:${last}"/><sheetViews><sheetView workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="18"/><cols>${headers.map((h,i)=>{const w=(h==="ruleLogic"?78:Math.min(42,Math.max(14,String(h).length+4)));return `<col min="${i+1}" max="${i+1}" width="${w}" customWidth="1"/>`;}).join("")}</cols><sheetData>${sheetRows}</sheetData><autoFilter ref="A1:${last}"/><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></worksheet>`;
  const zip=new JSZip();
  zip.file("[Content_Types].xml",types);zip.folder("_rels").file(".rels",rootRels);
  zip.folder("xl").file("workbook.xml",wb);zip.folder("xl").folder("_rels").file("workbook.xml.rels",wbRels);zip.folder("xl").file("styles.xml",styles);zip.folder("xl").folder("worksheets").file("sheet1.xml",sheet);
  const blob=await zip.generateAsync({type:"blob",compression:"DEFLATE"});
  const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="quality-companion-report.xlsx";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
async function processExcel(file){
  setStatus(`Opening Excel workbook… 0% • ${(file.size/1024/1024).toFixed(2)} MB`,"working");
  const started=performance.now();
  try{
    // Use the proven v1.3.10 workbook path. IMDRF resources are local and
    // never block Excel loading.
    await new Promise(requestAnimationFrame);
    setStatus(`Reading Excel workbook… 0% • ${(file.size/1024/1024).toFixed(2)} MB`,"working");
    globalThis.excelProgress=(phase,pct,detail)=>{
      const p=Math.max(0,Math.min(100,Math.round(Number(pct)||0)));
      setStatus(`${phase}… ${p}%${detail?` • ${detail}`:""}`,"working");
    };
    const sheets=await parseXLSX(file);
    delete globalThis.excelProgress;
    const names=Object.keys(sheets);
    setStatus(`Workbook opened • ${names.length} sheet${names.length===1?"":"s"}`,"working");
    if(!names.length)throw Error("No worksheet found.");
    const rows=xlsxRowsToObjects(sheets[names[0]]);
    if(!rows.length)throw Error("The first worksheet has no complaint rows.");

    workbookRows=rows;
    complaintCases=[];
    const engine=new QualityEngine(rowSpecificRules(),{imdrfStore});
    const chunkSize=10;

    // Execute ALL configured checks for every row. Small chunks + a paint yield
    // keep the progress text/bar visibly moving during large workbooks.
    setStatus(`Checking complaints… 0/${rows.length} (0%)`,"working");
    await new Promise(requestAnimationFrame);
    for(let i=0;i<rows.length;i+=chunkSize){
      const endRow=Math.min(i+chunkSize,rows.length);
      for(let j=i;j<endRow;j++){
        const row=rows[j];
        const cd=pageCase(row);
        const results=engine.run(cd);
        const statuses=results.map(x=>x.status);
        const overall=statuses.includes("FAIL")?"FAIL":statuses.includes("REVIEW")?"REVIEW":"PASS";
        complaintCases.push({case:cd,results,row,overall});
      }
      const pct=Math.round(endRow/rows.length*100);
      setStatus(`Checking complaints… ${endRow}/${rows.length} (${pct}%)`,"working");
      renderTotals();
      await new Promise(requestAnimationFrame);
    }

    $("sheetName").textContent=`Sheet: ${names[0]} • ${Object.keys(rows[0]).length} fields`;
    setStatus(`Checking complaints… ${rows.length}/${rows.length} (100%)`,"working");
    await new Promise(requestAnimationFrame);
    setStatus(`✓ ${rows.length} complaint rows checked in ${((performance.now()-started)/1000).toFixed(1)}s.`,"success");
    renderTotals();renderComplaintResults();
    $("exportJson").disabled=false;$("exportExcel").disabled=false;
    localStorage.setItem("quality_excel_filename",file.name);
  }catch(e){
    delete globalThis.excelProgress;
    console.error(e);setStatus(`✕ ${e.message}`,"error");
  }
}
$("excelFile").addEventListener("change",e=>{
  const f=e.target.files?.[0];if(f)processExcel(f);
});
$("clear").onclick=()=>{
  workbookRows=[];complaintCases=[];
  $("excelFile").value="";$("sheetName").textContent="—";$("rowCount").textContent="0 complaints";
  $("exportJson").disabled=true;$("exportExcel").disabled=true;
  $("complaintResults").innerHTML=`<div class="empty">Upload an Excel file to begin.</div>`;
  renderTotals();setStatus("No Excel file loaded.","idle");
};
$("exportJson").addEventListener("click",()=>{ exportJson(); $("debugMenu").hidden=true; });
$("exportExcel").addEventListener("click",exportExcel);
const debugExportBtn=$("debugExport");
const debugMenu=$("debugMenu");
if(debugExportBtn&&debugMenu){
  debugExportBtn.addEventListener("click",e=>{e.stopPropagation(); debugMenu.hidden=!debugMenu.hidden;});
  document.addEventListener("click",()=>{debugMenu.hidden=true;});
  debugMenu.addEventListener("click",e=>e.stopPropagation());
}

document.querySelectorAll(".filter").forEach(btn=>{
  btn.addEventListener("click",()=>{
    document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));
    btn.classList.add("active");currentFilter=btn.dataset.filter;renderComplaintResults();
  });
});

async function refreshIMDRFResults(){
  if(!complaintCases.length || !imdrfStore?.ready) return;
  for(const c of complaintCases){
    const engine=new QualityEngine([], {imdrfStore});
    const t=engine.text.bind(engine);
    engine.caseData=c.case;
    const arResult=c.results.find(r=>r.id==="CO-043");
    if(arResult){
      const ar=engine.field(engine.text("complaint"),["AR Codes","Complaint: AR Codes"]);
      const ev=engine.field(engine.text("complaint"),["Event Description","Complaint: Event Description"]);
      if(ar.found && ev.found && !engine.empty(ev.value)){
        const verification=engine.verifyAR(ev.value,ar.value);
        const best=verification.top||verification.officialTop;
        const expected=best?`${best.code} — ${best.label||best.term||""}`:"No supported candidate";
        const sourceText=verification.evidence.length?` Evidence: ${verification.evidence.join(" + ")}.`:"";
        arResult.status=verification.status;
        arResult.message=verification.status==="PASS"
          ?`AR A-code ${verification.actual.join(", ")} matches the Event Description. Match confidence: ${verification.matchConfidence}%.${sourceText}`
          :verification.status==="REVIEW"
            ?`AR A-code ${verification.actual.join(", ")} is supported by an alternative IMDRF candidate, but the top candidate is not a complete dual-source match. Review confidence: ${verification.matchConfidence}%.${sourceText}`
            :`AR A-code ${verification.actual.join(", ")} does not match the top IMDRF suggestion ${expected}. Candidate confidence: ${verification.matchConfidence}%.`;
        arResult.current=ar.value; arResult.eventDescription=ev.value; arResult.expected=expected;
        arResult.suggestion=verification.dataset; arResult.officialSuggestions=verification.official;
        arResult.confidence=verification.matchConfidence; arResult.verification=verification;
      }
    }
    // Refresh CO-042 official candidates as well, without re-running all 44 CO rules.
    const aiResult=c.results.find(r=>r.id==="CO-042");
    if(aiResult){
      const ai=engine.field(engine.text("complaint"),["AI Codes","Complaint: AI Codes"]);
      const pa=engine.field(engine.text("complaint"),["Product Analysis"]);
      if(ai.found && pa.found && !engine.empty(pa.value)){
        const verification=engine.verifyAI(pa.value,ai.value);
        aiResult.verification=verification;
        aiResult.suggestion=verification.items.flatMap(x=>x.suggestions?.A||[]);
      }
    }
    const statuses=c.results.map(x=>x.status);
    c.overall=statuses.includes("FAIL")?"FAIL":statuses.includes("REVIEW")?"REVIEW":"PASS";
  }
  renderTotals();
  renderComplaintResults();
}

imdrfStore=new IMDRF.Store();
imdrfInitPromise=(async()=>{
  const statusEl=$("imdrfStatus");
  try{
    await imdrfStore.load();
    if(imdrfStore.ready){
      statusEl.innerHTML=`<span class="statusIcon">✓</span><span>${imdrfStore.items.length.toLocaleString()} official IMDRF 2026 terminology records loaded.</span>`;
      statusEl.className="status success";
      return true;
    }
    // Official terminology is manual-load only. Do not auto-load from cache
    // or the network during startup, so the status always reflects an explicit
    // user action.
    statusEl.innerHTML=`<span class="statusIcon">◎</span><span>IMDRF 2026 terminology not loaded</span>`;
    statusEl.className="status idle";
    return false;
  }catch(e){
    console.warn(e);
    statusEl.innerHTML=`<span class="statusIcon">!</span><span>IMDRF Coding Examples available; official terminology unavailable.</span>`;
    statusEl.className="status success";
    return false;
  }
})();
(async()=>{
  try{
    rules=await fetch(chrome.runtime.getURL("rules/all-rules.json")).then(r=>r.json());
    const co=rules.filter(r=>r.type==="CO").length;
    $("ruleMeta").textContent=`✓ ${co} executable CO verification rules loaded • ${rules.length} total workbook/workflow rules retained`;
    $("ruleMeta").className="status success";
  }catch(e){
    rules=[];$("ruleMeta").textContent="✕ Could not load rule library.";
    $("ruleMeta").className="status error";setStatus("✕ Could not load rule library.","error");
  }
})();

const loadImdrfBtn=$("loadImdrf");
if(loadImdrfBtn){
  loadImdrfBtn.onclick=async()=>{
    loadImdrfBtn.disabled=true; loadImdrfBtn.innerHTML=`<span class="buttonSpinner"></span> Loading IMDRF 2026…`;
    const statusEl=$("imdrfStatus");
    try{
      await imdrfStore.autoLoadOfficial();
      statusEl.innerHTML=`<span class="statusIcon">✓</span><span>Official IMDRF 2026 terminology loaded (${imdrfStore.items.length.toLocaleString()} records).</span>`;
      statusEl.className="status success";
      loadImdrfBtn.innerHTML=`<span class="buttonIcon">✓</span> IMDRF 2026 Loaded`;
      // Recalculate the existing CO-042/CO-043 coding evidence so official
      // candidates are actually populated after the terminology load.
      await refreshIMDRFResults();
    }catch(e){
      statusEl.innerHTML=`<span class="statusIcon">!</span><span>Could not load official IMDRF 2026 suggestions: ${esc(e.message)}</span>`;
      statusEl.className="status error";
      loadImdrfBtn.disabled=false; loadImdrfBtn.innerHTML=`<span class="buttonIcon">↻</span> Retry IMDRF 2026`;
    }
  };
}
