
function frequencyWeightedCodingEvidence(record) {
  const n = Math.max(1, Number(record?._frequency || 1));
  return Math.min(3, 1 + (n - 1) * 0.15);
}
const OFFICIAL_PAGE =
  "https://www.imdrf.org/documents/terminologies-categorized-adverse-event-reporting-aer-terms-terminology-and-codes";
// Official IMDRF 2026 consolidated JSON published on the terminology page.
// Use this stable first-party URL first; page discovery remains the fallback
// so a Drupal link change does not break the manual loader.
const OFFICIAL_2026_CONSOLIDATED_JSON =
  "https://www.imdrf.org/sites/default/files/2026-03/annexa-g-consolidated2026-revised_0.JSON";

const ANNEX_LABELS = {
  A: "Medical Device Problem",
  B: "Type of Investigation",
  C: "Investigation Findings",
  D: "Investigation Conclusion",
  G: "Medical Device Component"
};

function norm(s) {
  return String(s ?? "").toLowerCase().normalize("NFKD")
    .replace(/[^\p{L}\p{N}]+/gu, " ").trim();
}

function tokens(s) {
  return new Set(norm(s).split(/\s+/).filter(x => x.length > 2));
}

/*
  The official 2026 release provides a consolidated JSON plus individual
  Annex A-G JSON files. This loader discovers the current JSON links from
  the official IMDRF page instead of hard-coding fragile asset URLs.
*/
async function discoverOfficialJsonLinks() {
  const html = await fetch(OFFICIAL_PAGE, {credentials:"omit"}).then(r => {
    if (!r.ok) throw new Error(`IMDRF page returned HTTP ${r.status}`);
    return r.text();
  });

  const doc = new DOMParser().parseFromString(html, "text/html");
  const links = [...doc.querySelectorAll("a[href]")].map(a => ({
    text: (a.textContent || "").trim(),
    href: new URL(a.getAttribute("href"), OFFICIAL_PAGE).href,
    context: (a.parentElement?.parentElement?.innerText || a.parentElement?.innerText || "").slice(0,1500)
  })).filter(x => /\.json(?:[?#]|$)/i.test(x.href));

  // Prefer 2026 links and, where possible, the consolidated JSON.
  const candidates = links.filter(x => /2026/i.test(x.context + " " + x.href));
  const consolidated = candidates.find(x => /consolidated/i.test(x.context + " " + x.text));
  if (consolidated) return [consolidated.href];

  // Otherwise collect individual A-G links from the 2026 section.
  const out = [];
  for (const letter of ["A","B","C","D","E","F","G"]) {
    const found = candidates.find(x =>
      new RegExp(`Annex\\s*${letter}\\b`, "i").test(x.context) &&
      /json/i.test(x.text + " " + x.href)
    );
    if (found) out.push(found.href);
  }
  if (out.length >= 4) return out;
  return candidates.slice(0, 7).map(x => x.href);
}

function looksLikeCode(s) {
  return /^[A-G]\s*[\|:\-]\s*\d/i.test(String(s || "")) ||
         /^[A-G]\d{2,}/i.test(String(s || ""));
}

function codeAnnex(code) {
  const m = String(code || "").match(/^([A-G])/i);
  return m ? m[1].toUpperCase() : "";
}

function flatten(value, out = [], inheritedAnnex = "") {
  if (Array.isArray(value)) {
    for (const v of value) flatten(v, out, inheritedAnnex);
    return out;
  }
  if (!value || typeof value !== "object") return out;

  const keys = Object.keys(value);
  const codeKey = keys.find(k => /^(code|imdrf.?code|term.?code|id)$/i.test(k));
  const termKey = keys.find(k => /^(term|name|label|title)$/i.test(k));
  const defKey = keys.find(k => /^(definition|description)$/i.test(k));

  const code = codeKey ? String(value[codeKey] ?? "") : "";
  const term = termKey ? String(value[termKey] ?? "") : "";
  const definition = defKey ? String(value[defKey] ?? "") : "";
  const annex = codeAnnex(code) || inheritedAnnex;

  if (code && looksLikeCode(code) && (term || definition)) {
    out.push({code, term, definition, annex});
  }

  for (const [k,v] of Object.entries(value)) {
    let nextAnnex = inheritedAnnex;
    if (/annex/i.test(k) && /^[A-G]$/i.test(String(k).trim())) nextAnnex = String(k).trim().toUpperCase();
    flatten(v, out, nextAnnex);
  }
  return out;
}

function dedupe(items) {
  return [...new Map(items.map(x => [x.code, x])).values()];
}

function normalizeText(s) {
  return String(s ?? "").toLowerCase().normalize("NFKD")
    .replace(/[^\p{L}\p{N}\s/-]+/gu, " ")
    .replace(/\s+/g, " ").trim();
}
function tokenSet(s) {
  return new Set(normalizeText(s).split(/\s+/).filter(x => x.length > 1));
}
function charGrams(s) {
  const x=normalizeText(s).replace(/\s+/g,"_");
  const out=new Set();
  for(let i=0;i<x.length-2;i++) out.add(x.slice(i,i+3));
  return out;
}
function jaccard(a,b) {
  if(!a.size||!b.size)return 0;
  let hit=0; for(const x of a)if(b.has(x))hit++;
  return hit/(a.size+b.size-hit);
}
function phraseScore(q,t) {
  const nq=normalizeText(q), nt=normalizeText(t);
  if(!nq||!nt)return 0;
  if(nt===nq)return 1;
  if(nt.length>4 && nq.includes(nt))return .95;
  if(nq.length>4 && nt.includes(nq))return .90;
  return 0;
}
function score(query,item) {
  const q=normalizeText(query);
  const term=normalizeText(item.term);
  const def=normalizeText(item.definition);
  const qt=tokenSet(q), tt=tokenSet(term), dt=tokenSet(`${term} ${def}`);
  const lexical=jaccard(qt,dt);
  const termLex=jaccard(qt,tt);
  const chars=jaccard(charGrams(q),charGrams(`${term} ${def}`));
  const phrase=Math.max(phraseScore(q,term),phraseScore(q,def));
  // Prefer matches to the official term itself over definition-only matches.
  let score=.34*termLex+.28*lexical+.20*chars+.18*phrase;

  // Domain cues improve ranking without inventing terminology.
  const cues=[
    ["crack",["crack","fracture","split","torn"]],["scratch",["scratch","scratched"]],
    ["wear",["wear","worn","degradation","degraded"]],["peel",["peeled","delaminated"]],
    ["leak",["leak","leakage"]],["stuck",["sticking","resistance","jam"]],
    ["angulation",["positioning","malposition","alignment"]],["misalign",["misalignment","positioning"]],
    ["loose",["loose","intermittent","connection"]],["snag",["sticking","resistance"]],
    ["dent",["dent","deformation"]],["bent",["twisted","bent","deformation"]],
    ["broken",["break","fracture","failure"]],["image",["image","optical","display"]],
    ["lens",["lens","lenses","optical"]],["cable",["cable","wire","electrical"]]
  ];
  for(const [needle,alts] of cues){
    if(q.includes(needle) && alts.some(a=>dt.has(a))) score+=.055;
  }
  return Math.min(1,score);
}

class Store {
  constructor() { this.items=[]; this.version="Not loaded"; this.byAnnex=new Map(); this.ready=false; }

  rebuildIndex() {
    this.byAnnex=new Map();
    for (const item of this.items) {
      const a=item.annex || codeAnnex(item.code);
      if (!this.byAnnex.has(a)) this.byAnnex.set(a,[]);
      this.byAnnex.get(a).push(item);
    }
    this.ready=true;
  }

  async load() {
    // Do not activate cached terminology automatically. The UI intentionally
    // requires the user to click "Load IMDRF 2026" before official terminology
    // is considered loaded for this session.
    this.items = [];
    this.byAnnex = new Map();
    this.ready = false;
    this.version = "Official terminology not loaded";
  }

  async autoLoadOfficial() {
    // Manual load is intentionally a fresh site load. Do not silently reuse
    // an old cached terminology set when the user explicitly clicks the button.
    const discovered = await discoverOfficialJsonLinks().catch(e => {
      console.warn("Official IMDRF page discovery failed:", e);
      return [];
    });
    const urls = [OFFICIAL_2026_CONSOLIDATED_JSON, ...discovered]
      .filter((u,i,a)=>u && a.indexOf(u)===i);

    let all = [];
    for (const url of urls) {
      try {
        const r = await fetch(url, {credentials:"omit"});
        if (!r.ok) continue;
        const data = await r.json();
        all.push(...flatten(data));
        // The consolidated 2026 JSON already contains A-G. Stop after the
        // first successful consolidated load to avoid duplicate network work.
        if(url===OFFICIAL_2026_CONSOLIDATED_JSON && all.length) break;
      } catch (e) {
        console.warn("Could not load", url, e);
      }
    }
    all = dedupe(all);
    if (!all.length) throw new Error("Official JSON was found but no terminology records could be parsed.");
    this.items = all;
    this.version = "IMDRF 2026 — official";
    this.rebuildIndex();
    await chrome.storage.local.set({imdrfItems:all, imdrfVersion:this.version});
  }

  candidates(annex, query, n=5) {
    const pool=this.byAnnex.get(annex)||[];
    const ranked=pool.map(x=>({...x,score:score(query,x)}))
      .sort((a,b)=>b.score-a.score);

    // Keep the best official terms available even for weak semantic matches.
    const eligible=ranked.filter(x=>x.score>=.025);
    const sourceRank=eligible.length?eligible:ranked.slice(0,3);

    // Avoid returning five near-duplicate terms from the same lexical family.
    const selected=[];
    const usedFamilies=new Set();
    for(const x of sourceRank){
      const family=normalizeText(x.term).split(/\s+/).slice(0,2).join(" ");
      if(selected.length<2 || !usedFamilies.has(family)){
        selected.push(x); usedFamilies.add(family);
      }
      if(selected.length>=n)break;
    }
    const top=selected[0]?.score||0;
    const second=selected[1]?.score||0;
    return selected.map((x,i)=>{
      const margin=i===0 ? (top-second) : (x.score-(selected[i+1]?.score||0));
      const confidence=Math.max(1,Math.min(99,Math.round(
        100*(.72*x.score+.28*Math.max(0,margin))
      )));
      return {
        ...x,
        confidence,
        confidenceLevel:confidence>=85?"High":confidence>=65?"Medium":"Low",
        matchReason: i===0 ? "Best official IMDRF terminology match" :
          "Alternative official IMDRF terminology match"
      };
    });
  }

  countByAnnex() {
    return ["A","B","C","D","G"].map(a => [a,this.items.filter(x=>x.annex===a).length]);
  }
}

window.IMDRF = {Store, ANNEX_LABELS, OFFICIAL_PAGE};